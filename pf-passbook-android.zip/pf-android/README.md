# PF Passbook (Android)

Shows your EPFO passbook as company-wise cards, a month-wise view and a sheet you can share as CSV.

## How sync works

1. Tap **Sync**. The official EPFO passbook site opens in the background, where you cannot see it.
2. The app shows its own form: UAN, password, and the captcha image taken from the EPFO page. You type the captcha yourself.
3. After you tap **Sign in and sync**, the app signs in, enters the OTP if you are asked for one, opens the passbook, goes through every company (member ID) and reads each table.
4. UAN and password are saved on the phone (encrypted with the Android Keystore) and filled in next time. The captcha is always typed by you.

If the EPFO page is not recognised, the sync screen shows **Open the official site instead**. That opens the real site on screen, with **Fill login** and **Read passbook** buttons for doing it by hand.

## Build the APK without a computer

Upload `pf-passbook-android.zip` (not extracted) to a GitHub repository, add `.github/workflows/build.yml` from this zip, and run **Actions > Build APK > Run workflow**. The APK is under Artifacts.

## Important limits

- This project has not been built or run against the live EPFO site. The background reader looks for a password box, a captcha image, an OTP box, a company drop-down (`select`) and a table with columns like Wage Month, Particulars, Employee Share, Employer Share and Pension Contribution. EPFO can name or build these differently, for example with a custom drop-down that is not a `select`.
- When something is not recognised, the sync screen says so and offers the official site. If you see "No passbook rows found", use **Share raw capture** on the dashboard and send that file so the reader can be corrected.
- EPFO changes its pages and sign-in flow from time to time. The app does not solve or skip the captcha.
- Dashboard figures are exactly what the passbook table says. They are not recalculated.

## Safety choices

- The JavaScript bridge exists only on the local dashboard page, never on EPFO pages. The app watches the EPFO page by reading its state, so EPFO scripts cannot call into the app.
- The EPFO view loads only `*.epfindia.gov.in`, and the saved password is filled in only on those hosts.
- Backups are off, and screenshots and recent-app previews are blocked (FLAG_SECURE).
- "Remove saved login" erases the stored UAN and password and clears the EPFO cookies.
