package com.pfpassbook.app

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File

/**
 * Two WebViews stacked in one screen:
 *  - portal: the real EPFO passbook site. It runs underneath, covered by the dashboard, so the person never sees it.
 *            It has no JS bridge, so EPFO pages can never call into the app.
 *  - dash:   local dashboard (assets/dashboard.html). Only this one gets the JS bridge.
 *
 * Sync works by polling the hidden EPFO page for its state (login form, captcha image, OTP box,
 * company list, passbook table) and driving it. The captcha image is shown in the dashboard and the
 * person types it. Nothing here solves or skips the captcha.
 *
 * If the EPFO page is not recognised, the dashboard offers to show the official site instead.
 */
class MainActivity : Activity() {

    companion object {
        const val DASH_URL = "file:///android_asset/dashboard.html"
        const val PORTAL_URL = "https://passbook.epfindia.gov.in/MemberPassBook/login"
        const val ALLOWED_HOST = "epfindia.gov.in"
        const val POLL_MS = 800L
    }

    private enum class Phase { IDLE, LOGIN, SUBMITTED, POST, READING }

    private lateinit var dash: WebView
    private lateinit var portal: WebView
    private lateinit var portalPane: LinearLayout
    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    // sync state
    private var phase = Phase.IDLE
    private var phaseStart = 0L
    private var sentCaptcha: String? = null
    private var warned = false
    private var otpAsked = false
    private var lastClick = 0L
    private var clicks = 0
    private var queue = ArrayDeque<String>()
    private var pending: String? = null
    private var pendingAt = 0L
    private var hashBefore = ""
    private var captured = 0
    private var showingSite = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Hides screen contents from recent-apps previews and screenshots.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        prefs = openPrefs()

        val root = FrameLayout(this)
        root.fitsSystemWindows = true
        root.setBackgroundColor(Color.parseColor("#F3F6F4"))

        portalPane = buildPortalPane()

        dash = WebView(this)
        dash.setBackgroundColor(Color.parseColor("#F3F6F4"))
        setupDash()

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        // Portal first, dashboard on top of it. The portal stays laid out and visible underneath.
        root.addView(portalPane, FrameLayout.LayoutParams(match, match))
        root.addView(dash, FrameLayout.LayoutParams(match, match))
        setContentView(root)

        dash.loadUrl(DASH_URL)
    }

    private fun openPrefs(): SharedPreferences {
        val key = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            this,
            "epfo_login",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    private fun setupDash() {
        dash.settings.javaScriptEnabled = true
        dash.settings.domStorageEnabled = true
        dash.settings.allowFileAccess = false
        dash.settings.allowContentAccess = false
        dash.webViewClient = object : WebViewClient() {
            // The dashboard never navigates away from its own page.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
        }
        dash.addJavascriptInterface(Bridge(), "Android")
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildPortalPane(): LinearLayout {
        val pane = LinearLayout(this)
        pane.orientation = LinearLayout.VERTICAL
        pane.setBackgroundColor(Color.WHITE)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(dp(8), dp(6), dp(8), dp(6))
        bar.setBackgroundColor(Color.parseColor("#0B3B2F"))

        fun barButton(label: String, onClick: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.isAllCaps = false
            b.setOnClickListener { onClick() }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginEnd = dp(6)
            bar.addView(b, lp)
        }
        barButton("Back") { hideSite() }
        barButton("Fill login") { fillLogin() }
        barButton("Read passbook") { readPassbookManually() }

        portal = WebView(this)
        setupPortal()

        pane.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        pane.addView(portal, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return pane
    }

    private fun isEpfoHost(url: String?): Boolean {
        val host = Uri.parse(url ?: return false).host ?: return false
        return host == ALLOWED_HOST || host.endsWith(".$ALLOWED_HOST")
    }

    private fun setupPortal() {
        portal.settings.javaScriptEnabled = true
        portal.settings.domStorageEnabled = true
        portal.settings.allowFileAccess = false
        portal.settings.allowContentAccess = false
        portal.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (isEpfoHost(request.url.toString())) return false
                Toast.makeText(this@MainActivity, "Blocked a link outside EPFO", Toast.LENGTH_SHORT).show()
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (showingSite && isEpfoHost(url)) fillLogin()
            }
        }
    }

    /* ---------- calls into the dashboard ---------- */

    private fun dashCall(fn: String, vararg args: String) {
        val list = args.joinToString(",") { JSONObject.quote(it) }
        dash.evaluateJavascript("window.$fn($list)", null)
    }

    /* ---------- official site fallback (manual) ---------- */

    private fun showSite() {
        stopSync()
        showingSite = true
        portalPane.bringToFront()
        if (portal.url == null) portal.loadUrl(PORTAL_URL) else fillLogin()
    }

    private fun hideSite() {
        showingSite = false
        dash.bringToFront()
    }

    /** Fills UAN and password on an EPFO page. The captcha is left for the person. */
    private fun fillLogin() {
        if (!isEpfoHost(portal.url)) return
        val uan = prefs.getString("uan", null) ?: return
        val pass = prefs.getString("pass", "") ?: ""
        val js = FILL_JS
            .replace("__U__", JSONObject.quote(uan))
            .replace("__P__", JSONObject.quote(pass))
        portal.evaluateJavascript(js, null)
    }

    private fun readPassbookManually() {
        if (!isEpfoHost(portal.url)) {
            Toast.makeText(this, "Open the EPFO passbook first", Toast.LENGTH_SHORT).show()
            return
        }
        portal.evaluateJavascript(CAPTURE_JS) { result ->
            if (result == null || result == "null") {
                Toast.makeText(this, "Could not read this page", Toast.LENGTH_SHORT).show()
            } else {
                dash.evaluateJavascript("window.ingest($result)", null)
                hideSite()
            }
        }
    }

    /* ---------- background sync ---------- */

    private val ticker = object : Runnable {
        override fun run() {
            if (phase == Phase.IDLE) return
            portal.evaluateJavascript(STATE_JS) { raw ->
                val st = parseState(raw)
                if (st != null && phase != Phase.IDLE) onState(st)
            }
            handler.postDelayed(this, POLL_MS)
        }
    }

    private fun parseState(raw: String?): JSONObject? {
        if (raw == null || raw == "null") return null
        return try {
            val v = JSONTokener(raw).nextValue()
            if (v is String) JSONObject(v) else null
        } catch (e: Exception) {
            null
        }
    }

    private fun startSync() {
        stopSync()
        showingSite = false
        phase = Phase.LOGIN
        phaseStart = SystemClock.elapsedRealtime()
        sentCaptcha = null
        warned = false
        otpAsked = false
        clicks = 0
        lastClick = 0L
        queue = ArrayDeque()
        pending = null
        captured = 0
        portal.loadUrl(PORTAL_URL)
        handler.postDelayed(ticker, POLL_MS)
    }

    private fun stopSync() {
        phase = Phase.IDLE
        handler.removeCallbacks(ticker)
    }

    private fun fallbackHint(msg: String) {
        if (warned) return
        warned = true
        dashCall("syncStatus", "fallback", msg)
    }

    private fun enterPost(now: Long) {
        phase = Phase.POST
        phaseStart = now
        warned = false
        clicks = 0
        lastClick = 0L
        dashCall("syncStatus", "info", "Signed in. Opening your passbook…")
    }

    private fun failSubmit(msg: String) {
        phase = Phase.LOGIN
        phaseStart = SystemClock.elapsedRealtime()
        sentCaptcha = null
        warned = false
        dashCall("syncStatus", "error", msg)
    }

    private fun onState(st: JSONObject) {
        val now = SystemClock.elapsedRealtime()
        val page = st.optString("page", "unknown")
        when (phase) {
            Phase.LOGIN -> {
                if (page == "login") {
                    val cap = st.optString("captcha", "")
                    if (cap.isNotEmpty() && cap != sentCaptcha) {
                        sentCaptcha = cap
                        dashCall("syncCaptcha", cap)
                    } else if (cap.isEmpty() && now - phaseStart > 25000) {
                        fallbackHint("The captcha did not load. You can use the official site instead.")
                    }
                } else if (page == "otp" || page == "select" || page == "passbook") {
                    // An earlier session is still valid, so EPFO skipped the login page.
                    enterPost(now)
                } else if (now - phaseStart > 25000) {
                    fallbackHint("Could not recognise the EPFO login page. You can use the official site instead.")
                }
            }

            Phase.SUBMITTED -> {
                val elapsed = now - phaseStart
                if (page == "login") {
                    val err = st.optString("error", "")
                    val cap = st.optString("captcha", "")
                    if (elapsed > 3500 && (err.isNotEmpty() || (cap.isNotEmpty() && cap != sentCaptcha))) {
                        failSubmit(if (err.isNotEmpty()) err else "Sign in was not accepted. Check the captcha and password, then try again.")
                    } else if (elapsed > 40000) {
                        failSubmit("EPFO did not respond. Try again.")
                    }
                } else if (page != "unknown" || elapsed > 6000) {
                    enterPost(now)
                }
            }

            Phase.POST -> {
                when (page) {
                    "login" -> failSubmit("EPFO signed you out. Enter the captcha and try again.")
                    "otp" -> if (!otpAsked) {
                        otpAsked = true
                        dashCall("syncStatus", "otp", "Enter the OTP sent to your registered mobile number.")
                    }
                    "select", "passbook" -> beginReading(st)
                    else -> {
                        if (now - lastClick > 4000 && clicks < 6) {
                            lastClick = now
                            clicks++
                            portal.evaluateJavascript(CLICK_PASSBOOK_JS, null)
                        }
                        if (now - phaseStart > 60000) {
                            fallbackHint("Could not find the passbook page. You can use the official site instead.")
                        }
                    }
                }
            }

            Phase.READING -> readStep(st, page, now)
            Phase.IDLE -> Unit
        }
    }

    private fun beginReading(st: JSONObject) {
        phase = Phase.READING
        pending = null
        hashBefore = ""
        queue = ArrayDeque()
        val opts = st.optJSONArray("options")
        if (opts != null) {
            for (i in 0 until opts.length()) queue.addLast(opts.optString(i))
        }
        dashCall("syncStatus", "info", "Reading your passbook…")
    }

    private fun readStep(st: JSONObject, page: String, now: Long) {
        if (page != "passbook" && page != "select") return
        val opts = st.optJSONArray("options")
        val hash = st.optString("hash", "")
        if (opts == null || opts.length() == 0) {
            // Only one company: its table is already on screen.
            if (page == "passbook" && hash.isNotEmpty()) {
                capture()
                finishSync()
            }
            return
        }
        val pend = pending
        if (pend == null) {
            val next = queue.removeFirstOrNull()
            if (next == null) {
                finishSync()
                return
            }
            if (page == "passbook" && hash.isNotEmpty() && st.optString("selected") == next) {
                // This company is already displayed.
                capture()
                hashBefore = hash
                return
            }
            pending = next
            pendingAt = now
            hashBefore = hash
            dashCall("syncStatus", "info", "Reading company " + (captured + 1) + "…")
            portal.evaluateJavascript(SELECT_JS.replace("__V__", JSONObject.quote(next)), null)
        } else {
            if (page == "passbook" && hash.isNotEmpty() && hash != hashBefore) {
                capture()
                pending = null
            } else if (now - pendingAt > 20000) {
                pending = null
            }
        }
    }

    private fun capture() {
        portal.evaluateJavascript(CAPTURE_JS) { result ->
            if (result != null && result != "null") {
                captured++
                dash.evaluateJavascript("window.ingest($result)", null)
            }
        }
    }

    private fun finishSync() {
        stopSync()
        // Give the last capture a moment to arrive before reporting.
        handler.postDelayed({
            if (captured > 0) {
                dashCall("syncStatus", "done", "Synced $captured passbook pages.")
            } else {
                dashCall("syncStatus", "fallback", "No passbook table was found. You can use the official site instead.")
            }
        }, 1500)
    }

    private fun doSubmit(captcha: String, uanIn: String, passIn: String) {
        if (!isEpfoHost(portal.url)) {
            dashCall("syncStatus", "error", "The EPFO page is not ready yet. Wait a moment and try again.")
            return
        }
        val uan = uanIn.trim().ifEmpty { prefs.getString("uan", "") ?: "" }
        val pass = if (passIn.isEmpty()) (prefs.getString("pass", "") ?: "") else passIn
        if (uan.isEmpty() || pass.isEmpty()) {
            dashCall("syncStatus", "error", "Enter your UAN and password.")
            return
        }
        if (uanIn.trim().isNotEmpty() || passIn.isNotEmpty()) {
            prefs.edit().putString("uan", uan).putString("pass", pass).apply()
        }
        val js = FILL_SUBMIT_JS
            .replace("__U__", JSONObject.quote(uan))
            .replace("__P__", JSONObject.quote(pass))
            .replace("__C__", JSONObject.quote(captcha.trim()))
        phase = Phase.SUBMITTED
        phaseStart = SystemClock.elapsedRealtime()
        dashCall("syncStatus", "info", "Signing in…")
        portal.evaluateJavascript(js) { r ->
            if (r != null && r.contains("nofields")) {
                phase = Phase.LOGIN
                phaseStart = SystemClock.elapsedRealtime()
                dashCall("syncStatus", "fallback", "Could not find the login boxes on the EPFO page. You can use the official site instead.")
            }
        }
    }

    /* ---------- files ---------- */

    private fun shareFile(name: String, text: String) {
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dir = File(cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, safe).apply { writeText(text) }
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = if (safe.endsWith(".csv")) "text/csv" else "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "Share $safe"))
    }

    inner class Bridge {
        @JavascriptInterface
        fun startSync() { runOnUiThread { this@MainActivity.startSync() } }

        @JavascriptInterface
        fun cancelSync() { runOnUiThread { stopSync() } }

        @JavascriptInterface
        fun refreshCaptcha() {
            runOnUiThread {
                sentCaptcha = null
                portal.evaluateJavascript(REFRESH_CAPTCHA_JS, null)
            }
        }

        @JavascriptInterface
        fun submitLogin(captcha: String, uan: String, pass: String) {
            runOnUiThread { doSubmit(captcha, uan, pass) }
        }

        @JavascriptInterface
        fun submitOtp(otp: String) {
            runOnUiThread {
                if (!isEpfoHost(portal.url)) return@runOnUiThread
                otpAsked = false
                dashCall("syncStatus", "info", "Checking the OTP…")
                portal.evaluateJavascript(OTP_JS.replace("__O__", JSONObject.quote(otp.trim())), null)
            }
        }

        @JavascriptInterface
        fun showSite() { runOnUiThread { this@MainActivity.showSite() } }

        @JavascriptInterface
        fun hasLogin(): Boolean = prefs.getString("uan", null) != null

        @JavascriptInterface
        fun savedUan(): String = prefs.getString("uan", "") ?: ""

        @JavascriptInterface
        fun saveLogin(uan: String, pass: String) {
            prefs.edit().putString("uan", uan.trim()).putString("pass", pass).apply()
        }

        @JavascriptInterface
        fun clearLogin() {
            prefs.edit().clear().apply()
            runOnUiThread { CookieManager.getInstance().removeAllCookies(null) }
        }

        @JavascriptInterface
        fun shareFile(name: String, text: String) { runOnUiThread { this@MainActivity.shareFile(name, text) } }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (showingSite) hideSite() else super.onBackPressed()
    }

    override fun onDestroy() {
        stopSync()
        portal.destroy()
        dash.destroy()
        super.onDestroy()
    }
}

/* ===================== scripts run inside the EPFO page ===================== */
/* No dollar signs in these scripts: Kotlin would read them as templates. */

private val PRELUDE = """
var PF = (function () {
  var docs = [document];
  [].slice.call(document.querySelectorAll('iframe')).forEach(function (f) {
    try { if (f.contentDocument) docs.push(f.contentDocument); } catch (e) {}
  });
  function vis(e) { return !!e && (e.offsetParent !== null || (e.getClientRects && e.getClientRects().length > 0)); }
  function all(sel) {
    var r = [];
    docs.forEach(function (d) { r = r.concat([].slice.call(d.querySelectorAll(sel))); });
    return r;
  }
  function setVal(el, v) {
    var proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    var d = Object.getOwnPropertyDescriptor(proto, 'value');
    if (d && d.set) d.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }
  function hint(e) {
    return ((e.id || '') + ' ' + (e.name || '') + ' ' + (e.placeholder || '') + ' ' + (e.className || '') + ' ' +
      (e.alt || '') + ' ' + (e.getAttribute ? (e.getAttribute('aria-label') || '') : '')).toLowerCase();
  }
  function capInput() {
    return all('input').filter(function (i) { return vis(i) && /captcha|capcha/.test(hint(i)); })[0];
  }
  function capImg() {
    var imgs = all('img').filter(function (i) {
      return vis(i) && /captcha|capcha/.test(hint(i) + ' ' + (i.src || '').slice(0, 120).toLowerCase());
    });
    if (imgs.length) return imgs[0];
    var ci = capInput();
    if (ci) {
      var p = ci.parentElement;
      for (var k = 0; k < 5 && p; k++) {
        var im = p.querySelector('img');
        if (im && vis(im)) return im;
        p = p.parentElement;
      }
    }
    return null;
  }
  function selects() {
    return all('select').filter(vis).map(function (s) {
      var opts = [].slice.call(s.options).map(function (o) { return { v: o.value, t: (o.text || '').trim() }; })
        .filter(function (o) { return o.v && !/select|choose/i.test(o.t); });
      var near = ((s.parentElement && s.parentElement.innerText) || '').slice(0, 120);
      var ok = opts.some(function (o) { return /[A-Z]{4,6}[0-9]{10,}/.test(o.v + ' ' + o.t); }) ||
        /member|establishment|company/i.test(hint(s) + ' ' + near);
      return { sel: s, opts: opts, ok: ok };
    }).filter(function (x) { return x.ok && x.opts.length > 0; });
  }
  function clickText(re, maxLen) {
    var els = all('a,button,[role=button],input[type=submit],input[type=button],li,span,div').filter(function (e) {
      if (!vis(e)) return false;
      var t = ((e.tagName === 'INPUT' ? e.value : e.innerText) || '').trim();
      return t && t.length <= maxLen && re.test(t) && e.children.length <= 2;
    });
    if (!els.length) return false;
    els.sort(function (a, b) {
      var ta = ((a.tagName === 'INPUT' ? a.value : a.innerText) || '').length;
      var tb = ((b.tagName === 'INPUT' ? b.value : b.innerText) || '').length;
      return ta - tb;
    });
    els[0].click();
    return true;
  }
  return { docs: docs, vis: vis, all: all, setVal: setVal, hint: hint, capInput: capInput, capImg: capImg, selects: selects, clickText: clickText };
})();
"""

private val STATE_BODY = """
var st = { page: 'unknown' };
var pw = PF.all('input[type=password]').filter(PF.vis)[0];
var otp = PF.all('input').filter(function (i) { return PF.vis(i) && /otp/.test(PF.hint(i)); })[0];
var tbl = PF.all('table').filter(function (t) {
  var x = (t.innerText || '').toLowerCase();
  return x.indexOf('particulars') > -1 || x.indexOf('wage month') > -1;
})[0];
var sels = PF.selects();
if (pw) st.page = 'login';
else if (otp) st.page = 'otp';
else if (tbl) st.page = 'passbook';
else if (sels.length) st.page = 'select';
else {
  var bt = (document.body ? document.body.innerText : '').toLowerCase();
  if (bt.indexOf('passbook') > -1) st.page = 'home';
}
if (sels.length) {
  st.options = sels[0].opts.map(function (o) { return o.v; });
  st.selected = sels[0].sel.value;
}
if (tbl) {
  var s = tbl.innerText || '';
  var h = 5381;
  for (var i = 0; i < s.length; i++) { h = ((h * 33) ^ s.charCodeAt(i)) >>> 0; }
  st.hash = String(h);
}
if (pw) {
  var im = PF.capImg();
  if (im) {
    var key = im.src;
    if (window.__capKey === key && window.__capData) {
      st.captcha = window.__capData;
    } else if (im.complete && im.naturalWidth) {
      try {
        var c = document.createElement('canvas');
        c.width = im.naturalWidth; c.height = im.naturalHeight;
        c.getContext('2d').drawImage(im, 0, 0);
        window.__capData = c.toDataURL('image/png');
        window.__capKey = key;
        st.captcha = window.__capData;
      } catch (e) {
        if (!window.__capFetching) {
          window.__capFetching = true;
          fetch(im.src, { credentials: 'include' }).then(function (r) { return r.blob(); }).then(function (b) {
            var fr = new FileReader();
            fr.onload = function () { window.__capData = fr.result; window.__capKey = key; window.__capFetching = false; };
            fr.readAsDataURL(b);
          }).catch(function () { window.__capFetching = false; });
        }
      }
    }
  }
  var errs = PF.all('.error,.alert,.alert-danger,.text-danger,[role=alert],.toast,.toast-message,.mat-error,.swal2-popup,.invalid-feedback,.errormsg,.message')
    .filter(PF.vis)
    .map(function (e) { return (e.innerText || '').trim(); })
    .filter(function (t) { return t && t.length < 200 && /invalid|incorrect|wrong|fail|expired|not match|error|locked|blocked/i.test(t); });
  if (errs.length) st.error = errs[0];
}
return JSON.stringify(st);
"""

private val STATE_JS = "(function () {\n" + PRELUDE + STATE_BODY + "\n})()"

private val FILL_SUBMIT_JS = "(function (u, p, c) {\n" + PRELUDE + """
var pw = PF.all('input[type=password]').filter(PF.vis)[0];
if (!pw) return 'nofields';
var us = PF.all('input').filter(function (i) {
  return PF.vis(i) && (i.type === 'text' || i.type === 'tel' || i.type === 'number' || i.type === '') && !/captcha|capcha|otp/.test(PF.hint(i));
})[0];
var ci = PF.capInput();
if (us) PF.setVal(us, u);
PF.setVal(pw, p);
if (ci && c) PF.setVal(ci, c);
setTimeout(function () {
  if (!PF.clickText(/^(log\s*in|login|sign\s*in|submit|continue)${'$'}/i, 16)) {
    var f = pw.form;
    if (f) { if (f.requestSubmit) f.requestSubmit(); else f.submit(); }
  }
}, 350);
return 'ok';
""" + "\n})(__U__, __P__, __C__);"

private val SELECT_JS = "(function (v) {\n" + PRELUDE + """
var s = PF.selects()[0];
if (!s) return 'noselect';
PF.setVal(s.sel, v);
setTimeout(function () {
  PF.clickText(/^(view|submit|go|show|get|search|proceed)( passbook)?${'$'}/i, 24);
}, 400);
return 'ok';
""" + "\n})(__V__);"

private val CLICK_PASSBOOK_JS = "(function () {\n" + PRELUDE + """
return PF.clickText(/passbook/i, 40) ? 'clicked' : 'none';
""" + "\n})();"

private val REFRESH_CAPTCHA_JS = "(function () {\n" + PRELUDE + """
window.__capData = null;
window.__capKey = null;
var im = PF.capImg();
if (!im) return 'noimg';
var p = im.parentElement, btn = null;
for (var k = 0; k < 4 && p && !btn; k++) {
  btn = [].slice.call(p.querySelectorAll('a,button,i,span,img,svg')).filter(function (e) {
    return e !== im && PF.vis(e) && /refresh|reload|regenerat|sync/.test(PF.hint(e) + ' ' + (e.title || '') + ' ' + ((e.innerText || '').toLowerCase()));
  })[0];
  p = p.parentElement;
}
(btn || im).click();
return 'ok';
""" + "\n})();"

private val OTP_JS = "(function (o) {\n" + PRELUDE + """
var i = PF.all('input').filter(function (x) { return PF.vis(x) && /otp/.test(PF.hint(x)); })[0];
if (!i) return 'nootp';
PF.setVal(i, o);
setTimeout(function () { PF.clickText(/verify|submit|login|continue|proceed/i, 24); }, 300);
return 'ok';
""" + "\n})(__O__);"

/* Manual fallback: fills UAN and password on a visible EPFO page. */
private val FILL_JS = """
(function (u, p) {
  function visible(el) { return el && el.offsetParent !== null; }
  function setVal(el, v) {
    var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
    setter.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  var all = [].slice.call(document.querySelectorAll('input'));
  var pw = all.filter(function (i) { return i.type === 'password' && visible(i); })[0];
  var us = all.filter(function (i) {
    return (i.type === 'text' || i.type === 'tel' || i.type === 'number') && visible(i) &&
      !/captcha/i.test((i.name || '') + (i.id || '') + (i.placeholder || ''));
  })[0];
  if (us && u) setVal(us, u);
  if (pw && p) setVal(pw, p);
  var cap = all.filter(function (i) { return /captcha/i.test((i.name || '') + (i.id || '') + (i.placeholder || '')) && visible(i); })[0];
  if (cap) cap.focus();
})(__U__, __P__);
"""

private val CAPTURE_JS = """
(function () {
  var docs = [document];
  [].slice.call(document.querySelectorAll('iframe')).forEach(function (f) {
    try { if (f.contentDocument) docs.push(f.contentDocument); } catch (e) {}
  });
  var tables = [], text = '';
  docs.forEach(function (d) {
    text += (d.body ? d.body.innerText : '') + '\n';
    [].slice.call(d.querySelectorAll('table')).forEach(function (t) {
      tables.push([].slice.call(t.rows).map(function (r) {
        return [].slice.call(r.cells).map(function (c) { return (c.innerText || '').trim().replace(/\s+/g, ' '); });
      }));
    });
  });
  return JSON.stringify({ text: text.slice(0, 30000), tables: tables });
})()
"""
