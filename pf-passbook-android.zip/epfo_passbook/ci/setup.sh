set -e
flutter create . --platforms=android --org com.epfo --project-name epfo_passbook
rm -f test/widget_test.dart
f=$(find android/app/src/main -name MainActivity.kt)
cp ci/MainActivity.kt "$f"
sed -i 's#<application#<uses-permission android:name="android.permission.USE_BIOMETRIC"/>\n    <uses-permission android:name="android.permission.INTERNET"/>\n    <application#' android/app/src/main/AndroidManifest.xml
sed -i 's#android:label="[^"]*"#android:label="EPFO PASSBOOK"#' android/app/src/main/AndroidManifest.xml
bash ci/patch_gradle.sh
