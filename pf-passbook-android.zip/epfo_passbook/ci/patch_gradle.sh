#!/bin/bash
# Some plugin modules require compileSdk 36+ while they compile against less.
# Disable the AAR-metadata check in every Gradle project (root + plugins).
f=$(ls android/build.gradle.kts android/build.gradle 2>/dev/null | head -1)
[ -z "$f" ] && exit 1
grep -q "EPFO_AAR_PATCH" "$f" && exit 0
if [[ "$f" == *.kts ]]; then
  printf '\n// EPFO_AAR_PATCH\nsubprojects {\n    tasks.configureEach {\n        if (name.endsWith("AarMetadata")) {\n            enabled = false\n        }\n    }\n}\n' >> "$f"
else
  printf '\n// EPFO_AAR_PATCH\nsubprojects {\n    tasks.configureEach { t ->\n        if (t.name.endsWith("AarMetadata")) { t.enabled = false }\n    }\n}\n' >> "$f"
fi
echo "Patched $f"
