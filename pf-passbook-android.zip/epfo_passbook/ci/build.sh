#!/bin/bash
# Release APK build. --no-shrink avoids R8 missing-class errors.
set -o pipefail
bash ci/patch_gradle.sh || exit 1
for i in 1 2; do
  echo "=== build attempt $i ==="
  if flutter build apk --release --no-shrink --target-platform android-arm64 2>&1 | tee build.log; then
    exit 0
  fi
  echo "=========== SUMMARY OF FAILURE (attempt $i) ==========="
  grep -B2 -A10 "What went wrong" build.log | head -60
  grep -n "error:" build.log | head -30
done
exit 1
