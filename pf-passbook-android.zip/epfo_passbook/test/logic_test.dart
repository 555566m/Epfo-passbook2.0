import 'package:flutter_test/flutter_test.dart';
import 'package:epfo_passbook/logic.dart';
import 'package:epfo_passbook/reports_data.dart';
import 'package:epfo_passbook/vault.dart';

const hdr = 'company,establishment_id,member_id,date_of_joining,date_of_exit,month,date,opening,employee,employer,pension,employee_interest,employer_interest,withdrawal,closing\n';

void main() {
  test('FY mapping', () {
    expect(fyOf('2024-04'), '2024-25');
    expect(fyOf('2025-03'), '2024-25');
    expect(fyOf('2099-12'), '2099-00');
  });

  test('inr formatting uses Indian grouping', () {
    expect(inr(1234567.5), '₹12,34,567.50');
    expect(inr(999), '₹999.00');
    expect(inr(-1500), '-₹1,500.00');
    expect(inr0(12345.6), '₹12,346');
    expect(monthInitial('2026-11'), 'N');
  });

  test('csv parse keeps companies separate and skips duplicates', () {
    final csv = '$hdr'
        '"Acme, Pvt",E1,M1,2020-01-01,2021-01-01,2020-04,2020-04-30,0,1000,550,450,0,0,0,1550\n'
        'Acme,E1,M1,,,2020-05,2020-05-30,1550,1000,550,450,0,0,0,3100\n'
        'Beta,E2,M2,2021-02-01,,2021-04,2021-04-30,0,2000,1100,900,0,0,0,3100\n'
        'Beta,E2,M2,,,2021-04,2021-04-30,0,2000,1100,900,0,0,0,3100\n';
    final r = parseCsv(csv);
    expect(r.txns.length, 3);
    expect(r.errors.length, 1);
    expect(r.companies.length, 2);
    expect(r.companies['M1']!.name, 'Acme');
    final m1 = forCompany(r.txns, 'M1');
    final m2 = forCompany(r.txns, 'M2');
    expect(m1.length, 2);
    expect(m2.length, 1);
    expect(Totals.of(m1).emp, 2000);
    expect(Totals.of(m2).eps, 900);
  });

  test('total balance sums latest closing per company; EPS separate', () {
    final r = parseCsv('$hdr'
        'A,E1,M1,,,2020-04,2020-04-30,0,1000,550,450,0,0,0,1550\n'
        'A,E1,M1,,,2020-05,2020-05-30,1550,1000,550,450,0,0,0,3100\n'
        'B,E2,M2,,,2021-04,2021-04-30,0,100,50,40,0,0,0,150\n');
    expect(totalBalance(r.txns), 3250);
    expect(Totals.of(r.txns).eps, 940);
  });

  test('withdrawal and invalid rows', () {
    final r = parseCsv('$hdr'
        'A,E1,M1,,,2020-04,2020-04-30,3100,0,0,0,0,0,1000,2100\n'
        'A,E1,M1,,,bad,2020-04-30,0,0,0,0,0,0,0,0\n'
        'A,E1,M1,,,2020-06,2020-06-30,x,0,0,0,0,0,0,0\n');
    expect(r.txns.length, 1);
    expect(r.errors.length, 2);
    expect(Totals.of(r.txns).wd, 1000);
  });

  test('missing columns rejected; demo csv parses', () {
    expect(parseCsv('a,b\n1,2').txns, isEmpty);
    final d = parseCsv(demoCsv());
    expect(d.companies.length, 2);
    expect(d.errors, isEmpty);
    expect(d.companies.values.every((c) => c.name.startsWith('DEMO')), true);
  });

  test('estimated interest uses monthly opening balance', () {
    final r = parseCsv('$hdr'
        'A,E1,M1,,,2024-04,2024-04-30,0,1000,0,0,0,0,0,1000\n'
        'A,E1,M1,,,2024-05,2024-05-30,1000,1000,0,0,0,0,0,2000\n');
    expect(estimateInterest(r.txns, 12), closeTo(10.0, 0.001));
  });

  test('reports: pension separate, totals row, company filter', () {
    final r = parseCsv('$hdr'
        'A,E1,M1,,,2024-04,2024-04-30,0,1000,550,450,0,0,0,1550\n'
        'B,E2,M2,,,2024-04,2024-04-30,0,100,50,40,0,0,0,150\n');
    final cos = r.companies.values.toList();
    final p = buildReport(ReportType.pension, cos, r.txns, 8.25);
    expect(p.rows.length, 3);
    expect(p.rows.last.first, 'TOTAL');
    expect(p.rows.last.last, '490.00');
    final only = buildReport(ReportType.monthly, [cos.first], forCompany(r.txns, 'M1'), 8.25);
    expect(only.rows.length, 1);
    expect(only.rows.first[1], 'A');
    final y = buildReport(ReportType.yearly, cos, r.txns, 8.25);
    expect(y.rows.first.first, 'FY 2024-25');
    expect(y.rows.first.last, '1700.00');
  });

  test('vault encrypts and decrypts; wrong key fails', () {
    Vault.useKey(List<int>.generate(32, (i) => i));
    final s = Vault.seal('hello ₹ 123');
    expect(s.contains('hello'), false);
    expect(Vault.open(s), 'hello ₹ 123');
    expect(() => Vault.open(s, key: Vault.deriveKey('wrong')), throwsA(anything));
  });
}
