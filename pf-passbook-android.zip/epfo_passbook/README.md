# EPFO PASSBOOK (Flutter, offline, ad-free)

Build on GitHub: upload epfo_passbook.zip to the repo root, put main.yml at .github/workflows/main.yml.
The workflow unzips, runs ci/setup.sh (flutter create + Android patches), analyze, tests, builds the APK and
uploads it as artifact EPFO-PASSBOOK-apk.

## CSV format
company,establishment_id,member_id,date_of_joining,date_of_exit,month,date,opening,employee,employer,pension,employee_interest,employer_interest,withdrawal,closing
(month = YYYY-MM)

## Storage
SQLite table vault(k, kind, blob): every company/transaction record is AES-256-GCM encrypted. The key is held in
Android Keystore-backed secure storage. Passwords are stored only as salted SHA-256.

## Features
Dashboard, employee/employer/EPS screens, passbook (search, FY + month filter, sort, detail), company cards and
company-only passbook with switcher, monthly/yearly/interest reports (actual vs ESTIMATED), PDF/Excel/CSV export of
9 report types, password + fingerprint lock, auto-lock, encrypted backup/restore, English/Hindi, light/dark, DEMO data.
