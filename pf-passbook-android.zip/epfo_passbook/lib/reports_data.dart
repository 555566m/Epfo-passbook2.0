import 'logic.dart';
import 'models.dart';

enum ReportType { passbook, company, monthly, yearly, employee, employer, pension, interest, transactions }

const reportNames = <ReportType, String>{
  ReportType.passbook: 'Complete EPF Passbook',
  ReportType.company: 'Company-wise PF Report',
  ReportType.monthly: 'Month-wise Contribution Report',
  ReportType.yearly: 'Year-wise Contribution Report',
  ReportType.employee: 'Employee Share Report',
  ReportType.employer: 'Employer Share Report',
  ReportType.pension: 'Pension (EPS) Report',
  ReportType.interest: 'Interest Report',
  ReportType.transactions: 'Complete Transaction History',
};

class ReportData {
  final String title;
  final String note;
  final List<String> headers;
  final List<List<String>> rows;
  final Set<int> numCols;
  const ReportData(this.title, this.headers, this.rows, {this.note = '', this.numCols = const {}});
}

String _f(double v) => v.toStringAsFixed(2);

ReportData buildReport(ReportType t, List<Company> cos, List<Txn> all, double rate) {
  String nm(String id) => cos.where((c) => c.memberId == id).map((c) => c.name).firstOrNull ?? id;
  final asc = sorted(all, desc: false);
  final title = reportNames[t]!;
  switch (t) {
    case ReportType.passbook:
    case ReportType.transactions:
      return ReportData(title,
          ['Company', 'Month', 'Date', 'Opening', 'Employee', 'Employer', 'Pension (EPS)', 'Emp Interest', 'Er Interest', 'Withdrawal', 'Closing'],
          [for (final x in asc) [nm(x.memberId), x.month, x.date, _f(x.opening), _f(x.emp), _f(x.er), _f(x.eps), _f(x.empInt), _f(x.erInt), _f(x.wd), _f(x.closing)]],
          numCols: {3, 4, 5, 6, 7, 8, 9, 10});
    case ReportType.company:
      return ReportData(title,
          ['Company', 'Establishment ID', 'Member ID', 'Joined', 'Exit', 'Employee', 'Employer', 'Pension (EPS)', 'Interest', 'Total Contribution', 'Balance'],
          [
            for (final c in cos)
              () {
                final l = forCompany(all, c.memberId);
                final s = Totals.of(l);
                final b = latestClosing(l);
                return [c.name, na(c.estId), c.memberId, na(c.doj), c.doe.isEmpty ? '-' : c.doe, _f(s.emp), _f(s.er), _f(s.eps), _f(s.interest), _f(s.deposits), b == null ? 'Data Not Available' : _f(b)];
              }()
          ],
          numCols: {5, 6, 7, 8, 9, 10});
    case ReportType.monthly:
      return ReportData(title, ['Month', 'Company', 'Employee', 'Employer', 'Pension (EPS)', 'Total', 'Interest'],
          [for (final x in asc) [x.month, nm(x.memberId), _f(x.emp), _f(x.er), _f(x.eps), _f(x.deposits), _f(x.interest)]],
          numCols: {2, 3, 4, 5, 6});
    case ReportType.yearly:
      final fy = byFy(all);
      final keys = fy.keys.toList()..sort();
      return ReportData(title, ['Financial Year', 'Employee', 'Employer', 'Pension (EPS)', 'Interest', 'Total Deposits', 'Withdrawals', 'Closing Balance'], [
        for (final k in keys)
          () {
            final l = fy[k]!;
            final s = Totals.of(l);
            final close = l.map((x) => x.memberId).toSet().fold(0.0, (a, id) => a + (latestClosing(forCompany(l, id)) ?? 0));
            return ['FY $k', _f(s.emp), _f(s.er), _f(s.eps), _f(s.interest), _f(s.deposits), _f(s.wd), _f(close)];
          }()
      ], numCols: {1, 2, 3, 4, 5, 6, 7});
    case ReportType.employee:
      return ReportData(title, ['Month', 'Company', 'Employee Contribution', 'Employee Interest'], [
        for (final x in asc) [x.month, nm(x.memberId), _f(x.emp), _f(x.empInt)],
        ['TOTAL', '', _f(Totals.of(all).emp), _f(Totals.of(all).empInt)],
      ], numCols: {2, 3});
    case ReportType.employer:
      return ReportData(title, ['Month', 'Company', 'Employer EPF Contribution', 'Employer Interest'], [
        for (final x in asc) [x.month, nm(x.memberId), _f(x.er), _f(x.erInt)],
        ['TOTAL', '', _f(Totals.of(all).er), _f(Totals.of(all).erInt)],
      ], note: 'EPS pension is reported separately and is not part of this EPF contribution.', numCols: {2, 3});
    case ReportType.pension:
      return ReportData(title, ['Month', 'Company', 'EPS Contribution'], [
        for (final x in asc) [x.month, nm(x.memberId), _f(x.eps)],
        ['TOTAL', '', _f(Totals.of(all).eps)],
      ], note: 'EPS is separate from the interest-bearing EPF balance.', numCols: {2});
    case ReportType.interest:
      final fy = byFy(all);
      final keys = fy.keys.toList()..sort();
      final rows = <List<String>>[];
      for (final k in keys) {
        for (final c in cos) {
          final l = forCompany(fy[k]!, c.memberId);
          if (l.isEmpty) continue;
          final s = Totals.of(l);
          rows.add(['FY $k', c.name, _f(s.empInt), _f(s.erInt), _f(s.interest), _f(estimateInterest(l, rate))]);
        }
      }
      return ReportData(title, ['Financial Year', 'Company', 'Actual Employee Interest', 'Actual Employer Interest', 'Actual Total', 'ESTIMATED (not credited)'], rows,
          note: 'Actual = credited entries from passbook. ESTIMATED = monthly opening balance x $rate% / 12 (assumed rate, indicative only).', numCols: {2, 3, 4, 5});
  }
}
