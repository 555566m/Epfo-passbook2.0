import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';
import 'dart:math';
import 'db.dart';
import 'logic.dart';
import 'models.dart';
import 'vault.dart';

const _store = FlutterSecureStorage();

class AppState extends ChangeNotifier {
  List<Company> companies = [];
  List<Txn> txns = [];
  String? lastSync;
  bool demo = false;
  bool lockEnabled = true;
  int autoLockSecs = 0;
  bool pinSet = false;
  bool bioEnabled = true;
  DateTime? lastAuthAt;
  ThemeMode themeMode = ThemeMode.system;
  String lang = 'en';
  double rate = 8.25; // user-editable, used only for ESTIMATED interest
  bool authenticating = false;
  final _auth = LocalAuthentication();

  bool get hasData => txns.isNotEmpty;
  double get balance => totalBalance(txns);
  String nameOf(String id) => companies.where((c) => c.memberId == id).map((c) => c.name).firstOrNull ?? id;

  Future<void> init() async {
    var k = await _store.read(key: 'dbkey');
    if (k == null) {
      k = base64.encode(Vault.newKeyBytes());
      await _store.write(key: 'dbkey', value: k);
    }
    Vault.useKey(base64.decode(k));
    await Db.i.open();
    await reload();
    lockEnabled = await _store.read(key: 'lock') != '0'; // lock is ON by default
    pinSet = await _store.read(key: 'pin_hash') != null;
    bioEnabled = await _store.read(key: 'bio') != '0';
    demo = await _store.read(key: 'demo') == '1';
    lastSync = await _store.read(key: 'sync');
    autoLockSecs = int.tryParse(await _store.read(key: 'autolock') ?? '') ?? 0;
    final th = await _store.read(key: 'theme');
    themeMode = ThemeMode.values.firstWhere((m) => m.name == th, orElse: () => ThemeMode.system);
    lang = await _store.read(key: 'lang') ?? 'en';
    rate = double.tryParse(await _store.read(key: 'rate') ?? '') ?? 8.25;
  }

  Future<void> reload() async {
    companies = await Db.i.companies();
    txns = await Db.i.txns();
  }

  Future<String> importCsv(String text, {bool isDemo = false}) async {
    final r = parseCsv(text);
    if (r.txns.isEmpty) return r.errors.isEmpty ? 'No rows found' : r.errors.first;
    final added = await Db.i.save(r.companies.values, r.txns);
    await reload();
    if (isDemo) demo = true;
    await _store.write(key: 'demo', value: demo ? '1' : '0');
    lastSync = DateTime.now().toIso8601String().substring(0, 16).replaceAll('T', ' ');
    await _store.write(key: 'sync', value: lastSync);
    notifyListeners();
    final skipped = r.txns.length - added;
    return 'Imported $added transactions${skipped > 0 ? ', $skipped already present' : ''}${r.errors.isNotEmpty ? ', ${r.errors.length} rows skipped' : ''}';
  }

  Future<void> loadDemo() => importCsv(demoCsv(), isDemo: true);

  Future<void> deleteAll() async {
    await Db.i.clear();
    companies = [];
    txns = [];
    demo = false;
    lastSync = null;
    await _store.delete(key: 'demo');
    await _store.delete(key: 'sync');
    notifyListeners();
  }

  // ---- encrypted backup / restore (password-protected AES-256-GCM) ----
  String backupText(String password) {
    final data = jsonEncode({'v': 1, 'companies': companies.map((c) => c.toMap()).toList(), 'txns': txns.map((t) => t.toMap()).toList()});
    return Vault.seal(data, key: Vault.deriveKey(password));
  }

  Future<String> restoreBackup(String text, String password) async {
    try {
      final data = jsonDecode(Vault.open(text.trim(), key: Vault.deriveKey(password))) as Map<String, dynamic>;
      final cs = (data['companies'] as List).map((e) => Company.fromMap(Map<String, Object?>.from(e as Map)));
      final ts = (data['txns'] as List).map((e) => Txn.fromMap(Map<String, Object?>.from(e as Map)));
      final added = await Db.i.save(cs, ts);
      await reload();
      notifyListeners();
      return 'Restored $added new transactions';
    } catch (_) {
      return 'Restore failed: wrong password or invalid file';
    }
  }

  // ---- settings ----
  Future<void> setTheme(ThemeMode m) async {
    themeMode = m;
    await _store.write(key: 'theme', value: m.name);
    notifyListeners();
  }

  Future<void> setLang(String l) async {
    lang = l;
    await _store.write(key: 'lang', value: l);
    notifyListeners();
  }

  Future<void> setRate(double r) async {
    rate = r;
    await _store.write(key: 'rate', value: '$r');
    notifyListeners();
  }

  Future<void> setAutoLock(int s) async {
    autoLockSecs = s;
    await _store.write(key: 'autolock', value: '$s');
    notifyListeners();
  }

  // ---- app lock (Android BiometricPrompt; raw biometric data is never accessed) ----
  Future<bool> biometricAvailable() async {
    try {
      return await _auth.canCheckBiometrics && (await _auth.getAvailableBiometrics()).isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<bool> biometric() async {
    authenticating = true;
    try {
      return await _auth.authenticate(
          localizedReason: 'Unlock EPFO PASSBOOK',
          options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true));
    } catch (_) {
      return false;
    } finally {
      lastAuthAt = DateTime.now();
      authenticating = false;
    }
  }

  String _hash(String salt, String pin) => sha256.convert(utf8.encode('$salt:$pin')).toString();

  Future<void> setPin(String pin) async {
    final salt = base64Url.encode(List<int>.generate(16, (_) => Random.secure().nextInt(256)));
    await _store.write(key: 'pin_salt', value: salt);
    await _store.write(key: 'pin_hash', value: _hash(salt, pin));
    pinSet = true;
  }

  Future<bool> verifyPin(String pin) async {
    final salt = await _store.read(key: 'pin_salt');
    final h = await _store.read(key: 'pin_hash');
    return salt != null && h != null && _hash(salt, pin) == h;
  }

  Future<void> setBio(bool on) async {
    bioEnabled = on;
    await _store.write(key: 'bio', value: on ? '1' : '0');
    notifyListeners();
  }

  Future<void> setLock(bool on) async {
    lockEnabled = on;
    await _store.write(key: 'lock', value: on ? '1' : '0');
    notifyListeners();
  }
}

final state = AppState();
