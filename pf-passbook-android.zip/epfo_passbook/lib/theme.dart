import 'package:flutter/material.dart';

const green = Color(0xFF1B9E5A);

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final cs = ColorScheme.fromSeed(seedColor: green, brightness: b);
  return ThemeData(
    useMaterial3: true,
    colorScheme: cs,
    scaffoldBackgroundColor: dark ? const Color(0xFF101412) : Colors.white,
    appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent, elevation: 0, scrolledUnderElevation: 0,
        titleTextStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: 0.5, color: cs.onSurface)),
    cardTheme: CardThemeData(
        elevation: 2, shadowColor: Colors.black12, margin: EdgeInsets.zero,
        color: dark ? const Color(0xFF1A201D) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
    navigationBarTheme: NavigationBarThemeData(
        height: 72, backgroundColor: dark ? const Color(0xFF101412) : Colors.white, elevation: 0,
        indicatorColor: Colors.transparent,
        labelTextStyle: const WidgetStatePropertyAll(TextStyle(fontWeight: FontWeight.w700, fontSize: 14))),
  );
}
