import 'dart:convert';

/// Official EPFO member passbook portal (login needs UAN, password and captcha entered by the user).
const epfoLoginUrl = 'https://passbook.epfindia.gov.in/MemberPassBook/Login';

/// Light probe, run every 2s: tells the app whether the login form / home page / a data table is showing.
const lightProbe = r'''(function(){try{
var t=document.body?(document.body.innerText||''):'';
var o={type:'light',url:location.href,login:!!document.querySelector('input[placeholder="Enter Captcha"]'),sig:0};
if(t.indexOf('Total Available Balance')>=0){o.home=t.substring(0,8000);}
var n=0;Array.prototype.forEach.call(document.querySelectorAll('table'),function(tb){var c=tb.querySelectorAll('tr').length;if(c>2)n+=c;});
o.sig=n;
EpfoApp.postMessage(JSON.stringify(o));
}catch(e){}})();''';

/// Reads every table on the page (all columns, including the ones hidden off-screen to the right).
const tablesProbe = r'''(function(){try{
var re=/[A-Z]{4,6}[0-9]{10,22}/;
var tbs=Array.prototype.map.call(document.querySelectorAll('table'),function(tb){
 return Array.prototype.map.call(tb.querySelectorAll('tr'),function(tr){
  return Array.prototype.map.call(tr.querySelectorAll('th,td'),function(c){return (c.innerText||'').replace(/\s+/g,' ').trim();});
 }).filter(function(r){return r.length>0;});
}).filter(function(r){return r.length>2;});
var sel=document.querySelector('select');var mid=null;
if(sel&&sel.selectedIndex>=0){var m=(sel.options[sel.selectedIndex].text||'').match(re);if(m)mid=m[0];}
var txt=document.body?(document.body.innerText||''):'';
if(!mid){var m2=txt.match(re);if(m2)mid=m2[0];}
EpfoApp.postMessage(JSON.stringify({type:'tables',mid:mid,tables:tbs,text:txt.substring(0,60000)}));
}catch(e){}})();''';

/// Opens the portal's Passbook menu entry.
const clickPassbook = r'''(function(){
var els=Array.prototype.filter.call(document.querySelectorAll('a,li,button,span,div'),function(e){
 return e.children.length<=2&&(e.innerText||'').trim().toLowerCase()==='passbook';});
if(els.length){var a=els[0].closest('a')||els[0];a.click();}
})();''';

/// Fills the official login form (UAN + password). The captcha is always typed by the user.
String fillJs(String uan, String pw) => '''(function(u,p){
function setVal(el,v){var s=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;s.call(el,v);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}
var a=document.querySelector('input[placeholder="UAN Number"]');
var b=document.querySelector('input[placeholder="Password"]');
var c=document.querySelector('input[placeholder="Enter Captcha"]');
if(a&&b){setVal(a,u);setVal(b,p);}
if(c){c.focus();c.addEventListener('input',function(){
 if(c.value.length>=6){var btn=Array.prototype.filter.call(document.querySelectorAll('button,input[type=submit]'),function(x){return /sign\\s*in/i.test((x.innerText||x.value||''));})[0];if(btn)btn.click();}
});}
})(${jsonEncode(uan)},${jsonEncode(pw)});''';
