import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'i18n.dart';
import 'logic.dart';
import 'models.dart';
import 'screens/sync.dart';
import 'state.dart';

class StatCard extends StatelessWidget {
  final String label, value;
  final VoidCallback? onTap;
  const StatCard(this.label, this.value, {super.key, this.onTap});
  @override
  Widget build(BuildContext c) => Card(
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, style: Theme.of(c).textTheme.bodySmall?.copyWith(color: Theme.of(c).colorScheme.onSurfaceVariant)),
              const SizedBox(height: 6),
              Text(value, style: Theme.of(c).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            ]),
          ),
        ),
      );
}

class DemoBadge extends StatelessWidget {
  const DemoBadge({super.key});
  @override
  Widget build(BuildContext c) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(color: Colors.orange.shade100, borderRadius: BorderRadius.circular(20)),
        child: const Text('DEMO DATA', style: TextStyle(color: Colors.deepOrange, fontWeight: FontWeight.bold, fontSize: 12)),
      );
}

class Bars extends StatelessWidget {
  final List<MapEntry<String, double>> items;
  const Bars(this.items, {super.key});
  @override
  Widget build(BuildContext c) {
    final mx = items.fold<double>(1, (m, e) => e.value > m ? e.value : m);
    return SizedBox(
      height: 130,
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        for (final e in items)
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 2),
              child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                Container(height: 90 * e.value / mx, decoration: BoxDecoration(color: Theme.of(c).colorScheme.primary, borderRadius: BorderRadius.circular(6))),
                const SizedBox(height: 4),
                Text(e.key, style: const TextStyle(fontSize: 9)),
              ]),
            ),
          ),
      ]),
    );
  }
}

Future<void> pickAndImport(BuildContext c) async {
  final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['csv'], withData: true);
  final bytes = r?.files.single.bytes;
  if (bytes == null) return;
  final msg = await state.importCsv(utf8.decode(bytes, allowMalformed: true));
  if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(msg)));
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key});
  @override
  Widget build(BuildContext c) => Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.account_balance_wallet_outlined, size: 64),
            const SizedBox(height: 16),
            Text(tr('No data imported'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            const Text('Check your EPF online (log in on the official EPFO page) or import a passbook CSV. Nothing is shown until real records are loaded.', textAlign: TextAlign.center),
            const SizedBox(height: 20),
            FilledButton.icon(onPressed: () => openSync(c), icon: const Icon(Icons.cloud_sync_outlined), label: const Text('Check online EPF')),
            const SizedBox(height: 8),
            OutlinedButton.icon(onPressed: () => pickAndImport(c), icon: const Icon(Icons.upload_file), label: Text(tr('Import CSV'))),
            TextButton(onPressed: state.loadDemo, child: Text(tr('Load DEMO data'))),
          ]),
        ),
      );
}

void showTxn(BuildContext c, Txn t) {
  Widget row(String a, String b) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(a), Text(b, style: const TextStyle(fontWeight: FontWeight.w600))]));
  showModalBottomSheet(
    context: c,
    showDragHandle: true,
    builder: (_) => Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('${monthLabel(t.month)} • ${state.nameOf(t.memberId)}', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        row('Transaction date', na(t.date)),
        row('Opening balance', inr(t.opening)),
        row('Employee contribution', inr(t.emp)),
        row('Employer contribution (EPF)', inr(t.er)),
        row('Pension (EPS)', inr(t.eps)),
        row('Employee interest', inr(t.empInt)),
        row('Employer interest', inr(t.erInt)),
        row('Withdrawal', inr(t.wd)),
        row('Closing balance', inr(t.closing)),
      ]),
    ),
  );
}

Future<String?> askText(BuildContext c, String title, {bool obscure = false, String hint = '', TextInputType? type}) {
  final ctl = TextEditingController();
  return showDialog<String>(
    context: c,
    builder: (d) => AlertDialog(
      title: Text(title),
      content: TextField(controller: ctl, obscureText: obscure, keyboardType: type, decoration: InputDecoration(hintText: hint)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(d, ctl.text), child: const Text('OK')),
      ],
    ),
  );
}
