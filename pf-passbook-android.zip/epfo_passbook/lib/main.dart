import 'package:flutter/material.dart';
import 'lock.dart';
import 'screens/shell.dart';
import 'state.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await state.init();
  runApp(const EpfoApp());
}

class EpfoApp extends StatelessWidget {
  const EpfoApp({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: state,
        builder: (_, __) => MaterialApp(
          title: 'EPFO PASSBOOK',
          debugShowCheckedModeBanner: false,
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark),
          themeMode: state.themeMode,
          home: const LockGate(child: Shell()),
        ),
      );
}
