class Company {
  final String memberId, name, estId, doj, doe;
  const Company({required this.memberId, required this.name, this.estId = '', this.doj = '', this.doe = ''});
  Map<String, Object?> toMap() => {'member_id': memberId, 'name': name, 'est_id': estId, 'doj': doj, 'doe': doe};
  factory Company.fromMap(Map<String, Object?> m) => Company(
      memberId: m['member_id'] as String,
      name: m['name'] as String,
      estId: (m['est_id'] ?? '') as String,
      doj: (m['doj'] ?? '') as String,
      doe: (m['doe'] ?? '') as String);
}

class Txn {
  final String memberId, month, date;
  final double opening, emp, er, eps, empInt, erInt, wd, closing;
  const Txn({
    required this.memberId, required this.month, required this.date,
    required this.opening, required this.emp, required this.er, required this.eps,
    required this.empInt, required this.erInt, required this.wd, required this.closing});
  String get key => '$memberId|$month|$date|$emp|$er|$eps|$empInt|$erInt|$wd';
  double get deposits => emp + er + eps;
  double get interest => empInt + erInt;
  Map<String, Object?> toMap() => {
        'member_id': memberId, 'month': month, 'date': date, 'opening': opening,
        'emp': emp, 'er': er, 'eps': eps, 'emp_int': empInt, 'er_int': erInt, 'wd': wd, 'closing': closing};
  factory Txn.fromMap(Map<String, Object?> m) => Txn(
      memberId: m['member_id'] as String, month: m['month'] as String, date: (m['date'] ?? '') as String,
      opening: (m['opening'] as num).toDouble(), emp: (m['emp'] as num).toDouble(),
      er: (m['er'] as num).toDouble(), eps: (m['eps'] as num).toDouble(),
      empInt: (m['emp_int'] as num).toDouble(), erInt: (m['er_int'] as num).toDouble(),
      wd: (m['wd'] as num).toDouble(), closing: (m['closing'] as num).toDouble());
}

/// Snapshot of the EPFO passbook portal home page (read after the user logs in).
class LiveSummary {
  final String at, estName, estId, memberId, doj, exp;
  final double total;
  final double? emp, er;
  final List<MapEntry<String, double>> members;
  const LiveSummary({
    required this.at, required this.total, this.emp, this.er, this.estName = '', this.estId = '',
    this.memberId = '', this.doj = '', this.exp = '', this.members = const []});
  Map<String, Object?> toJson() => {
        'at': at, 'total': total, 'emp': emp, 'er': er, 'estName': estName, 'estId': estId,
        'memberId': memberId, 'doj': doj, 'exp': exp,
        'members': [for (final m in members) [m.key, m.value]]};
  factory LiveSummary.fromJson(Map<String, dynamic> j) => LiveSummary(
      at: (j['at'] ?? '') as String, total: (j['total'] as num).toDouble(),
      emp: (j['emp'] as num?)?.toDouble(), er: (j['er'] as num?)?.toDouble(),
      estName: (j['estName'] ?? '') as String, estId: (j['estId'] ?? '') as String,
      memberId: (j['memberId'] ?? '') as String, doj: (j['doj'] ?? '') as String, exp: (j['exp'] ?? '') as String,
      members: [for (final e in (j['members'] as List)) MapEntry((e as List)[0] as String, (e[1] as num).toDouble())]);
}

/// Passbook table (or raw text if the page had no table) captured for one member id.
class Captured {
  final String at, text;
  final List<List<String>> rows;
  const Captured({required this.at, this.rows = const [], this.text = ''});
  Map<String, Object?> toJson() => {'at': at, 'rows': rows, 'text': text};
  factory Captured.fromJson(Map<String, dynamic> j) => Captured(
      at: (j['at'] ?? '') as String,
      text: (j['text'] ?? '') as String,
      rows: [for (final r in (j['rows'] as List)) [for (final c in (r as List)) c.toString()]]);
}
