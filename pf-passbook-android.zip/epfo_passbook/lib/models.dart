class Company {
  final String memberId, name, estId, doj, doe;
  const Company({required this.memberId, required this.name, this.estId = '', this.doj = '', this.doe = ''});
  Map<String, Object?> toMap() => {'member_id': memberId, 'name': name, 'est_id': estId, 'doj': doj, 'doe': doe};
  factory Company.fromMap(Map<String, Object?> m) => Company(
      memberId: m['member_id'] as String,
      name: m['name'] as String,
      estId: (m['est_id'] ?? '') as String,
      doj: (m['doj'] ?? '') as String,
      doe: (m['doe'] ?? '') as String);
}

class Txn {
  final String memberId, month, date;
  final double opening, emp, er, eps, empInt, erInt, wd, closing;
  const Txn({
    required this.memberId, required this.month, required this.date,
    required this.opening, required this.emp, required this.er, required this.eps,
    required this.empInt, required this.erInt, required this.wd, required this.closing});
  String get key => '$memberId|$month|$date|$emp|$er|$eps|$empInt|$erInt|$wd';
  double get deposits => emp + er + eps;
  double get interest => empInt + erInt;
  Map<String, Object?> toMap() => {
        'member_id': memberId, 'month': month, 'date': date, 'opening': opening,
        'emp': emp, 'er': er, 'eps': eps, 'emp_int': empInt, 'er_int': erInt, 'wd': wd, 'closing': closing};
  factory Txn.fromMap(Map<String, Object?> m) => Txn(
      memberId: m['member_id'] as String, month: m['month'] as String, date: (m['date'] ?? '') as String,
      opening: (m['opening'] as num).toDouble(), emp: (m['emp'] as num).toDouble(),
      er: (m['er'] as num).toDouble(), eps: (m['eps'] as num).toDouble(),
      empInt: (m['emp_int'] as num).toDouble(), erInt: (m['er_int'] as num).toDouble(),
      wd: (m['wd'] as num).toDouble(), closing: (m['closing'] as num).toDouble());
}
