import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:encrypt/encrypt.dart' as enc;

/// AES-256-GCM helpers. The database key lives in Android Keystore-backed secure storage.
class Vault {
  static enc.Key? _key;

  static void useKey(List<int> bytes) => _key = enc.Key(Uint8List.fromList(bytes));
  static List<int> newKeyBytes() => List<int>.generate(32, (_) => Random.secure().nextInt(256));

  static enc.Key deriveKey(String password) {
    var d = sha256.convert(utf8.encode('epfo-backup:$password')).bytes;
    for (var i = 0; i < 20000; i++) {
      d = sha256.convert(d).bytes;
    }
    return enc.Key(Uint8List.fromList(d));
  }

  static String seal(String plain, {enc.Key? key}) {
    final k = key ?? _key!;
    final iv = enc.IV.fromSecureRandom(12);
    final c = enc.Encrypter(enc.AES(k, mode: enc.AESMode.gcm)).encryptBytes(utf8.encode(plain), iv: iv);
    return base64.encode([...iv.bytes, ...c.bytes]);
  }

  static String open(String s, {enc.Key? key}) {
    final k = key ?? _key!;
    final all = base64.decode(s);
    final iv = enc.IV(Uint8List.fromList(all.sublist(0, 12)));
    final plain = enc.Encrypter(enc.AES(k, mode: enc.AESMode.gcm)).decryptBytes(enc.Encrypted(Uint8List.fromList(all.sublist(12))), iv: iv);
    return utf8.decode(plain);
  }
}
