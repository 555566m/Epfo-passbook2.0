import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'logic.dart';
import 'models.dart';
import 'vault.dart';

/// Every record is stored AES-256-GCM encrypted; the DB file holds only opaque blobs.
class Db {
  Db._();
  static final Db i = Db._();
  late Database _db;

  Future<void> open() async {
    final p = join(await getDatabasesPath(), 'epfo_v2.db');
    _db = await openDatabase(p, version: 1, onCreate: (d, v) async {
      await d.execute('CREATE TABLE vault(k TEXT PRIMARY KEY, kind TEXT NOT NULL, blob TEXT NOT NULL)');
    });
  }

  String _h(String s) => sha256.convert(utf8.encode(s)).toString();

  /// Returns number of newly inserted transactions (duplicates ignored).
  Future<int> save(Iterable<Company> cs, Iterable<Txn> ts) async {
    var n = 0;
    await _db.transaction((t) async {
      for (final c in cs) {
        await t.insert('vault', {'k': 'c:${_h(c.memberId)}', 'kind': 'c', 'blob': Vault.seal(jsonEncode(c.toMap()))}, conflictAlgorithm: ConflictAlgorithm.replace);
      }
      for (final x in ts) {
        final r = await t.insert('vault', {'k': 't:${_h(x.key)}', 'kind': 't', 'blob': Vault.seal(jsonEncode(x.toMap()))}, conflictAlgorithm: ConflictAlgorithm.ignore);
        if (r > 0) n++;
      }
    });
    return n;
  }

  Future<List<Company>> companies() async {
    final rows = await _db.query('vault', where: "kind = 'c'");
    final l = rows.map((r) => Company.fromMap(jsonDecode(Vault.open(r['blob'] as String)) as Map<String, Object?>)).toList();
    l.sort((a, b) => a.doj.compareTo(b.doj));
    return l;
  }

  Future<List<Txn>> txns() async {
    final rows = await _db.query('vault', where: "kind = 't'");
    final l = rows.map((r) => Txn.fromMap(jsonDecode(Vault.open(r['blob'] as String)) as Map<String, Object?>)).toList();
    return sorted(l, desc: false);
  }

  Future<void> clear() async => _db.delete('vault');
}
