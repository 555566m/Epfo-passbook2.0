import 'package:flutter/material.dart';
import 'state.dart';

class LockGate extends StatefulWidget {
  final Widget child;
  const LockGate({super.key, required this.child});
  @override
  State<LockGate> createState() => _LockGateState();
}

class _LockGateState extends State<LockGate> with WidgetsBindingObserver {
  bool locked = state.lockEnabled && state.pinSet; // cold start / refresh => login screen
  DateTime? bg;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (state.authenticating) return;
    if (s == AppLifecycleState.paused || s == AppLifecycleState.hidden) {
      bg ??= DateTime.now();
    } else if (s == AppLifecycleState.resumed) {
      final la = state.lastAuthAt;
      final justAuthed = la != null && DateTime.now().difference(la).inSeconds < 3;
      if (!justAuthed && bg != null && state.lockEnabled && state.pinSet && DateTime.now().difference(bg!).inSeconds >= state.autoLockSecs) {
        setState(() => locked = true);
      }
      bg = null;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (state.lockEnabled && !state.pinSet) {
      return SetupLockScreen(onDone: () => setState(() => locked = false));
    }
    return locked ? LockScreen(onUnlocked: () => setState(() => locked = false)) : widget.child;
  }
}

/// Gate before sensitive actions (export, reveal IDs, turning lock off).
Future<bool> requireAuth(BuildContext c) async {
  if (!state.lockEnabled) return true;
  final ok = await Navigator.of(c).push<bool>(MaterialPageRoute(builder: (ctx) => LockScreen(onUnlocked: () => Navigator.pop(ctx, true))));
  return ok ?? false;
}

InputDecoration _dec(String label, {String? err}) =>
    InputDecoration(labelText: label, errorText: err, border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(16))));

class LockScreen extends StatefulWidget {
  final VoidCallback onUnlocked;
  const LockScreen({super.key, required this.onUnlocked});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final pw = TextEditingController();
  String? err;
  bool bioOk = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _bio());
  }

  Future<void> _bio() async {
    bioOk = state.bioEnabled && await state.biometricAvailable();
    if (mounted) setState(() {});
    if (bioOk && await state.biometric()) widget.onUnlocked();
  }

  Future<void> _pw() async {
    if (await state.verifyPin(pw.text)) {
      widget.onUnlocked();
    } else {
      setState(() => err = 'Wrong password');
      pw.clear();
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(32),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.lock_outline, size: 72, color: Theme.of(c).colorScheme.primary),
                const SizedBox(height: 12),
                const Text('EPFO PASSBOOK', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: 1)),
                const SizedBox(height: 28),
                TextField(controller: pw, obscureText: true, textAlign: TextAlign.center, decoration: _dec('Password', err: err), onSubmitted: (_) => _pw()),
                const SizedBox(height: 12),
                SizedBox(width: double.infinity, child: FilledButton(onPressed: _pw, child: const Text('Unlock'))),
                if (bioOk) ...[
                  const SizedBox(height: 16),
                  IconButton.filledTonal(iconSize: 44, onPressed: _bio, icon: const Icon(Icons.fingerprint)),
                  const Text('Fingerprint / Face'),
                ],
              ]),
            ),
          ),
        ),
      );
}

/// First launch: the user must create a password. Fingerprint is then a quick unlock.
class SetupLockScreen extends StatefulWidget {
  final VoidCallback onDone;
  const SetupLockScreen({super.key, required this.onDone});
  @override
  State<SetupLockScreen> createState() => _SetupLockScreenState();
}

class _SetupLockScreenState extends State<SetupLockScreen> {
  final a = TextEditingController(), b = TextEditingController();
  String? err;

  Future<void> _save() async {
    if (a.text.length < 4) return setState(() => err = 'At least 4 characters');
    if (a.text != b.text) return setState(() => err = 'Passwords do not match');
    await state.setPin(a.text);
    await state.setLock(true);
    widget.onDone();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(32),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.shield_outlined, size: 72, color: Theme.of(c).colorScheme.primary),
                const SizedBox(height: 12),
                const Text('Create app password', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                const Text('Password is always required. Fingerprint can be used as a quick unlock.', textAlign: TextAlign.center),
                const SizedBox(height: 24),
                TextField(controller: a, obscureText: true, decoration: _dec('New password')),
                const SizedBox(height: 12),
                TextField(controller: b, obscureText: true, decoration: _dec('Confirm password', err: err)),
                const SizedBox(height: 16),
                SizedBox(width: double.infinity, child: FilledButton(onPressed: _save, child: const Text('Save and continue'))),
              ]),
            ),
          ),
        ),
      );
}
