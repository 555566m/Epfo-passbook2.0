import 'package:flutter/material.dart';
import '../export.dart';
import '../lock.dart';
import '../logic.dart';
import '../reports_data.dart';
import '../state.dart';

class ExportScreen extends StatefulWidget {
  const ExportScreen({super.key});
  @override
  State<ExportScreen> createState() => _ExportScreenState();
}

class _ExportScreenState extends State<ExportScreen> {
  ReportType type = ReportType.passbook;
  String? member; // null = all companies
  bool busy = false;

  Future<void> _go(String fmt) async {
    if (state.txns.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No data to export')));
      return;
    }
    if (!await requireAuth(context)) return;
    setState(() => busy = true);
    try {
      final cos = member == null ? state.companies : state.companies.where((c) => c.memberId == member).toList();
      final l = member == null ? state.txns : forCompany(state.txns, member!);
      await exportReport(buildReport(type, cos, l, state.rate), fmt);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Export failed: $e')));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Download Reports')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Report', style: TextStyle(fontWeight: FontWeight.w700)),
          DropdownButton<ReportType>(
            isExpanded: true,
            value: type,
            items: [for (final t in ReportType.values) DropdownMenuItem(value: t, child: Text(reportNames[t]!))],
            onChanged: (v) => setState(() => type = v ?? type),
          ),
          const SizedBox(height: 12),
          const Text('Company', style: TextStyle(fontWeight: FontWeight.w700)),
          DropdownButton<String?>(
            isExpanded: true,
            value: member,
            items: [const DropdownMenuItem<String?>(value: null, child: Text('All companies')), for (final co in state.companies) DropdownMenuItem<String?>(value: co.memberId, child: Text(co.name))],
            onChanged: (v) => setState(() => member = v),
          ),
          const SizedBox(height: 20),
          if (busy) const Center(child: CircularProgressIndicator()),
          if (!busy) ...[
            FilledButton.icon(onPressed: () => _go('pdf'), icon: const Icon(Icons.picture_as_pdf), label: const Text('PDF')),
            const SizedBox(height: 10),
            FilledButton.tonalIcon(onPressed: () => _go('xlsx'), icon: const Icon(Icons.grid_on), label: const Text('Excel (.xlsx)')),
            const SizedBox(height: 10),
            OutlinedButton.icon(onPressed: () => _go('csv'), icon: const Icon(Icons.table_chart_outlined), label: const Text('CSV')),
          ],
          const SizedBox(height: 16),
          const Text('App password / fingerprint is required before export when app lock is on.', style: TextStyle(fontSize: 12)),
        ]),
      );
}
