import 'package:flutter/material.dart';
import '../logic.dart';
import '../state.dart';
import '../theme.dart';
import 'sync.dart';

/// Passbook exactly as captured from the EPFO portal. Scroll right to see the last columns.
class OnlinePassbook extends StatefulWidget {
  final String? initial;
  const OnlinePassbook({super.key, this.initial});
  @override
  State<OnlinePassbook> createState() => _OnlinePassbookState();
}

class _OnlinePassbookState extends State<OnlinePassbook> {
  String? sel;

  @override
  Widget build(BuildContext c) => ListenableBuilder(listenable: state, builder: (c, _) => _body(c));

  Widget _body(BuildContext c) {
    final ids = state.captured.keys.toList()..sort();
    if (ids.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Passbook not captured yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('Open Online EPF Check, log in, open Passbook and select the member ID. The table is saved automatically (or tap "Save this page").', textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton(onPressed: () => openSync(c), child: const Text('Online EPF Check')),
          ]),
        ),
      );
    }
    sel ??= widget.initial;
    if (sel == null || !ids.contains(sel)) sel = ids.first;
    final cap = state.captured[sel]!;
    final bal = state.live?.members.where((m) => m.key == sel).map((m) => m.value).firstOrNull;
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
        child: Row(children: [
          Expanded(
            child: DropdownButton<String>(
              isExpanded: true,
              value: sel,
              items: [for (final i in ids) DropdownMenuItem(value: i, child: Text(i, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)))],
              onChanged: (v) => setState(() => sel = v),
            ),
          ),
          IconButton(icon: const Icon(Icons.sync), tooltip: 'Refresh from EPFO', onPressed: () => openSync(c)),
        ]),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text('Fetched ${cap.at}${cap.rows.isEmpty ? '' : '  •  ${cap.rows.length - 1} rows'}${bal == null ? '' : '  •  Balance ${inr0(bal)}'}  •  swipe right for more columns', style: Theme.of(c).textTheme.bodySmall),
        ),
      ),
      Expanded(child: cap.rows.isEmpty ? SingleChildScrollView(padding: const EdgeInsets.all(16), child: SelectableText(cap.text)) : _grid(c, cap.rows)),
    ]);
  }

  Widget _grid(BuildContext c, List<List<String>> rows) {
    final cols = rows.fold<int>(0, (a, r) => r.length > a ? r.length : a);
    const w = 130.0;
    Widget row(List<String> r, bool header) => Container(
          decoration: BoxDecoration(color: header ? green.withValues(alpha: 0.18) : null, border: const Border(bottom: BorderSide(color: Colors.black12))),
          child: Row(children: [
            for (var i = 0; i < cols; i++)
              SizedBox(width: w, child: Padding(padding: const EdgeInsets.all(8), child: Text(i < r.length ? r[i] : '', style: TextStyle(fontSize: 12, fontWeight: header ? FontWeight.w800 : FontWeight.w500)))),
          ]),
        );
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: cols * w,
        child: Column(children: [
          row(rows.first, true),
          Expanded(child: ListView.builder(itemCount: rows.length - 1, itemBuilder: (_, i) => row(rows[i + 1], false))),
        ]),
      ),
    );
  }
}

class OnlinePassbookScreen extends StatelessWidget {
  final String memberId;
  const OnlinePassbookScreen(this.memberId, {super.key});
  @override
  Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Passbook', style: TextStyle(fontSize: 18))), body: OnlinePassbook(initial: memberId));
}
