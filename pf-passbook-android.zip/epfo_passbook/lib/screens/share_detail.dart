import 'package:flutter/material.dart';
import '../logic.dart';
import '../models.dart';
import '../state.dart';

enum ShareKind { employee, employer, pension }

class ShareDetail extends StatelessWidget {
  final ShareKind kind;
  const ShareDetail(this.kind, {super.key});

  double _v(Txn t) => switch (kind) { ShareKind.employee => t.emp, ShareKind.employer => t.er, ShareKind.pension => t.eps };

  @override
  Widget build(BuildContext c) {
    final title = switch (kind) { ShareKind.employee => 'Employee Share', ShareKind.employer => 'Employer Share (EPF)', ShareKind.pension => 'Pension (EPS)' };
    final all = state.txns;
    final total = all.fold(0.0, (s, t) => s + _v(t));
    final totals = Totals.of(all);
    final double? interest = switch (kind) { ShareKind.employee => totals.empInt, ShareKind.employer => totals.erInt, ShareKind.pension => null };
    final fy = byFy(all);
    final fyKeys = fy.keys.toList()..sort((a, b) => b.compareTo(a));
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: ListTile(title: const Text('Total contribution'), trailing: Text(inr(total), style: const TextStyle(fontWeight: FontWeight.w800)))),
        const SizedBox(height: 8),
        Card(child: ListTile(title: const Text('Interest credited'), subtitle: kind == ShareKind.pension ? const Text('EPS earns no EPF interest') : null, trailing: Text(interest == null ? '—' : inr(interest)))),
        const SizedBox(height: 16),
        const Text('Financial year', style: TextStyle(fontWeight: FontWeight.w700)),
        for (final k in fyKeys) Padding(padding: const EdgeInsets.only(top: 8), child: Card(child: ListTile(title: Text('FY $k'), trailing: Text(inr(fy[k]!.fold(0.0, (s, t) => s + _v(t))))))),
        const SizedBox(height: 16),
        const Text('Month-wise', style: TextStyle(fontWeight: FontWeight.w700)),
        for (final t in sorted(all)) Padding(padding: const EdgeInsets.only(top: 8), child: Card(child: ListTile(title: Text('${monthLabel(t.month)} • ${state.nameOf(t.memberId)}'), trailing: Text(inr(_v(t)))))),
      ]),
    );
  }
}
