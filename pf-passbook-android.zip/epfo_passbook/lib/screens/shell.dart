import 'package:flutter/material.dart';
import '../i18n.dart';
import '../state.dart';
import '../theme.dart';
import 'companies.dart';
import 'export_screen.dart';
import 'home.dart';
import 'passbook.dart';
import 'reports.dart';
import 'sync.dart';
import 'settings.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int idx = 0;

  void _push(Widget w) {
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => w));
  }

  void _info(String t, String body) {
    Navigator.pop(context);
    showDialog(context: context, builder: (_) => AlertDialog(title: Text(t), content: Text(body), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))]));
  }

  void _tab(int i) {
    Navigator.pop(context);
    setState(() => idx = i);
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(listenable: state, builder: (c, _) => _scaffold(c));

  Widget _scaffold(BuildContext context) {
    Widget item(IconData i, String t, VoidCallback f) => ListTile(leading: Icon(i), title: Text(tr(t)), onTap: f);
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: false,
        toolbarHeight: 64,
        title: const Text('EPFO PASSBOOK', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
        actions: [
          Builder(
            builder: (ctx) => IconButton(
              onPressed: () => Scaffold.of(ctx).openEndDrawer(),
              padding: const EdgeInsets.all(16),
              icon: const Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
                SizedBox(width: 24, height: 2.5, child: DecoratedBox(decoration: BoxDecoration(color: Colors.grey))),
                SizedBox(height: 6),
                SizedBox(width: 16, height: 2.5, child: DecoratedBox(decoration: BoxDecoration(color: Colors.grey))),
              ]),
            ),
          ),
        ],
      ),
      endDrawer: Drawer(
        child: ListView(children: [
          const DrawerHeader(child: Align(alignment: Alignment.bottomLeft, child: Text('EPFO PASSBOOK', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)))),
          item(Icons.home_outlined, 'Home', () => _tab(0)),
          item(Icons.cloud_sync_outlined, 'Online EPF Check', () {
            Navigator.pop(context);
            openSync(context);
          }),
          item(Icons.menu_book_outlined, 'EPF Passbook', () => _tab(1)),
          item(Icons.business_outlined, 'Company Details', () => _tab(2)),
          item(Icons.percent, 'Interest Details', () => _push(const ReportsScreen(tab: 2))),
          item(Icons.calendar_month_outlined, 'Monthly Contributions', () => _push(const ReportsScreen(tab: 0))),
          item(Icons.event_note_outlined, 'Yearly Contributions', () => _push(const ReportsScreen(tab: 1))),
          item(Icons.receipt_long_outlined, 'Transaction History', () => _tab(1)),
          item(Icons.download_outlined, 'Download Reports', () => _push(const ExportScreen())),
          item(Icons.fingerprint, 'Fingerprint Security', () => _push(const SettingsScreen())),
          item(Icons.settings_outlined, 'Settings', () => _push(const SettingsScreen())),
          item(Icons.help_outline, 'Help & Support', () => _info('Help & Support', 'Import a CSV with columns: company, establishment_id, member_id, date_of_joining, date_of_exit, month (YYYY-MM), date, opening, employee, employer, pension, employee_interest, employer_interest, withdrawal, closing.\n\nOnline EPF Check opens the official EPFO passbook page: you type the captcha, the app reads the passbook shown after your login. You can also import a CSV.')),
          item(Icons.privacy_tip_outlined, 'Privacy Policy', () => _info('Privacy Policy', 'All data stays on this device, AES-256 encrypted. The internet is used only when you open Online EPF Check, and only to the official EPFO site (epfindia.gov.in). If you choose to save your UAN and password, they are kept encrypted on this device only, to auto-fill the EPFO page; OTPs are never stored and the captcha is always typed by you. No ads, no trackers. Biometrics are handled by Android; the app never sees fingerprint or face data.')),
          item(Icons.info_outline, 'About App', () => _info('About', 'EPFO PASSBOOK 2.2.0\nOffline EPF passbook viewer. Not affiliated with EPFO.')),
        ]),
      ),
      body: IndexedStack(index: idx, children: const [HomeScreen(), PassbookScreen(), CompaniesScreen()]),
      bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
        const Divider(height: 1),
        NavigationBar(
          selectedIndex: idx,
          onDestinationSelected: (i) => setState(() => idx = i),
          destinations: [
            NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home_outlined, color: green), label: tr('Home')),
            NavigationDestination(icon: const Icon(Icons.menu_book_outlined), selectedIcon: const Icon(Icons.menu_book_outlined, color: green), label: tr('Passbook')),
            NavigationDestination(icon: const Icon(Icons.business_outlined), selectedIcon: const Icon(Icons.business_outlined, color: green), label: tr('Companies')),
          ],
        ),
      ]),
    );
  }
}
