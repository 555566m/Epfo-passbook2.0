import 'package:flutter/material.dart';
import '../i18n.dart';
import '../logic.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'live_panel.dart';
import 'share_detail.dart';
import 'sync.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: state,
        builder: (c, _) {
          final live = state.live;
          if (!state.hasData && live == null) return const EmptyState();
          return ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 24), children: [
            Row(children: [
              Expanded(child: FilledButton.tonalIcon(onPressed: () => openSync(c), icon: const Icon(Icons.cloud_sync_outlined), label: Text(live == null ? 'Check online EPF' : 'Refresh from EPFO'))),
            ]),
            const SizedBox(height: 12),
            if (live != null) LivePanel(live) else ..._csvPanel(c),
            if (state.hasData) ..._csvExtras(c),
          ]);
        },
      );

  List<Widget> _csvPanel(BuildContext c) {
    final dark = Theme.of(c).brightness == Brightness.dark;
    final t = Totals.of(state.txns);
    final current = state.companies.where((x) => x.doe.isEmpty).map((x) => x.name).join(', ');
    void open(ShareKind k) => Navigator.push(c, MaterialPageRoute(builder: (_) => ShareDetail(k)));
    Widget cell(String label, String value, [VoidCallback? f]) => Expanded(
          child: InkWell(
            onTap: f,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(tr(label), style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: Theme.of(c).colorScheme.onSurfaceVariant)),
                const SizedBox(height: 6),
                FittedBox(fit: BoxFit.scaleDown, child: Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
              ]),
            ),
          ),
        );
    return [
      Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(color: dark ? const Color(0xFF1A201D) : const Color(0xFFF3F3F3), borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Text(tr('TOTAL EPF BALANCE'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            const Spacer(),
            if (state.demo) const DemoBadge(),
          ]),
          const SizedBox(height: 10),
          FittedBox(fit: BoxFit.scaleDown, child: Text(inr0(state.balance), style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: green))),
          const Divider(height: 28),
          Row(children: [cell('Employee Share', inr0(t.emp), () => open(ShareKind.employee)), const SizedBox(width: 12), cell('Employer Share', inr0(t.er), () => open(ShareKind.employer))]),
          Row(children: [cell('Pension (EPS)', inr0(t.eps), () => open(ShareKind.pension)), const SizedBox(width: 12), cell('Interest Earned', inr0(t.interest))]),
        ]),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: StatCard('Companies', '${state.companies.length}')),
        const SizedBox(width: 12),
        Expanded(child: StatCard('Current employer', current.isEmpty ? 'Data Not Available' : current)),
      ]),
    ];
  }

  List<Widget> _csvExtras(BuildContext c) {
    final months = <String, double>{};
    for (final x in state.txns) {
      months[x.month] = (months[x.month] ?? 0) + x.deposits;
    }
    final keys = months.keys.toList()..sort();
    final last = keys.length > 8 ? keys.sublist(keys.length - 8) : keys;
    final mx = last.fold<double>(1, (m, k) => months[k]! > m ? months[k]! : m);
    final recent = keys.reversed.take(3).toList();
    return [
      const SizedBox(height: 28),
      Text(tr('Monthly Contribution'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
      const SizedBox(height: 16),
      SizedBox(
        height: 170,
        child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          for (final k in last)
            Expanded(
              child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                Container(height: 30 + 110 * months[k]! / mx, margin: const EdgeInsets.symmetric(horizontal: 5), decoration: BoxDecoration(color: green, borderRadius: BorderRadius.circular(8))),
                const SizedBox(height: 8),
                Text(monthInitial(k), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
              ]),
            ),
        ]),
      ),
      const SizedBox(height: 24),
      Text(tr('Recent Transactions'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
      for (final k in recent) ...[
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(monthFull(k), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                Text(tr('Employee + Employer'), style: TextStyle(fontSize: 17, color: Theme.of(c).colorScheme.onSurfaceVariant)),
              ]),
            ),
            Text(inr0(months[k]!), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: green)),
          ]),
        ),
        const Divider(height: 1),
      ],
      const SizedBox(height: 12),
      Center(child: Text('${tr('Last import')}: ${na(state.lastSync ?? '')}', style: Theme.of(c).textTheme.bodySmall)),
    ];
  }
}
