import 'dart:convert';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../export.dart';
import '../i18n.dart';
import '../lock.dart';
import '../state.dart';
import '../widgets.dart';
import 'export_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _toggle(BuildContext c, bool on) async {
    if (!on) {
      if (!await requireAuth(c)) return;
      await state.setLock(false);
      return;
    }
    if (!state.pinSet) {
      final pw = await askText(c, 'Set app password', obscure: true, hint: 'At least 4 characters');
      if (pw == null || pw.length < 4) return;
      await state.setPin(pw);
    }
    await state.setLock(true);
  }

  Future<void> _backup(BuildContext c) async {
    if (!state.hasData) return;
    if (!await requireAuth(c)) return;
    if (!c.mounted) return;
    final pw = await askText(c, 'Backup password', obscure: true, hint: 'Remember this password');
    if (pw == null || pw.length < 4) return;
    await shareBytes('epfo_backup.epfobak', utf8.encode(state.backupText(pw)));
  }

  Future<void> _restore(BuildContext c) async {
    final r = await FilePicker.platform.pickFiles(withData: true);
    final bytes = r?.files.single.bytes;
    if (bytes == null || !c.mounted) return;
    final pw = await askText(c, 'Backup password', obscure: true);
    if (pw == null || !c.mounted) return;
    final msg = await state.restoreBackup(utf8.decode(bytes, allowMalformed: true), pw);
    if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext c) => ListenableBuilder(
        listenable: state,
        builder: (c, _) => Scaffold(
          appBar: AppBar(title: Text(tr('Settings'))),
          body: ListView(children: [
            SwitchListTile(title: Text(tr('App lock (password)')), subtitle: const Text('Password is asked every time the app opens'), value: state.lockEnabled, onChanged: (v) => _toggle(c, v)),
            SwitchListTile(title: Text(tr('Fingerprint / Face unlock')), subtitle: const Text('Quick unlock; password always works too'), value: state.bioEnabled, onChanged: state.lockEnabled ? (v) => state.setBio(v) : null),
            ListTile(
              title: Text(tr('Auto-lock time')),
              trailing: DropdownButton<int>(value: state.autoLockSecs, items: const [DropdownMenuItem(value: 0, child: Text('Immediately')), DropdownMenuItem(value: 30, child: Text('30 sec')), DropdownMenuItem(value: 60, child: Text('1 min')), DropdownMenuItem(value: 300, child: Text('5 min'))], onChanged: (v) => state.setAutoLock(v ?? 0)),
            ),
            if (state.lockEnabled)
              ListTile(
                title: Text(tr('Change password')),
                onTap: () async {
                  if (!await requireAuth(c)) return;
                  if (!c.mounted) return;
                  final p = await askText(c, 'New password', obscure: true, hint: 'At least 4 characters');
                  if (p != null && p.length >= 4) await state.setPin(p);
                },
              ),
            const Divider(),
            ListTile(
              title: Text(tr('Theme')),
              trailing: DropdownButton<ThemeMode>(value: state.themeMode, items: const [DropdownMenuItem(value: ThemeMode.system, child: Text('System')), DropdownMenuItem(value: ThemeMode.light, child: Text('Light')), DropdownMenuItem(value: ThemeMode.dark, child: Text('Dark'))], onChanged: (v) => state.setTheme(v ?? ThemeMode.system)),
            ),
            ListTile(
              title: Text(tr('Language')),
              trailing: DropdownButton<String>(value: state.lang, items: const [DropdownMenuItem(value: 'en', child: Text('English')), DropdownMenuItem(value: 'hi', child: Text('हिन्दी'))], onChanged: (v) => state.setLang(v ?? 'en')),
            ),
            ListTile(
              title: Text(tr('Interest rate (estimates)')),
              subtitle: const Text('Used only for ESTIMATED interest, never for actual credited interest'),
              trailing: Text('${state.rate}%'),
              onTap: () async {
                final s = await askText(c, 'Interest rate % p.a.', type: const TextInputType.numberWithOptions(decimal: true), hint: '8.25');
                final v = double.tryParse(s ?? '');
                if (v != null && v >= 0 && v <= 20) await state.setRate(v);
              },
            ),
            const Divider(),
            ListTile(leading: const Icon(Icons.upload_file), title: Text(tr('Import CSV')), onTap: () => pickAndImport(c)),
            ListTile(leading: const Icon(Icons.download_outlined), title: Text(tr('Export data')), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const ExportScreen()))),
            ListTile(leading: const Icon(Icons.backup_outlined), title: Text(tr('Create encrypted backup')), onTap: () => _backup(c)),
            ListTile(leading: const Icon(Icons.restore), title: Text(tr('Restore backup')), onTap: () => _restore(c)),
            ListTile(leading: const Icon(Icons.science_outlined), title: Text(tr('Load DEMO data')), onTap: state.loadDemo),
            ListTile(
              leading: const Icon(Icons.delete_forever, color: Colors.red),
              title: Text(tr('Delete all local data')),
              onTap: () async {
                if (!await requireAuth(c)) return;
                if (!c.mounted) return;
                showDialog(
                  context: c,
                  builder: (d) => AlertDialog(
                    title: const Text('Delete all data?'),
                    content: const Text('All imported records will be removed from this device.'),
                    actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')), FilledButton(onPressed: () { state.deleteAll(); Navigator.pop(d); }, child: const Text('Delete'))],
                  ),
                );
              },
            ),
            ListTile(title: Text(tr('App version')), trailing: const Text('2.0.0')),
          ]),
        ),
      );
}
