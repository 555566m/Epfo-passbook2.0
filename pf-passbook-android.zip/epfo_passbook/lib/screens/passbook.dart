import 'package:flutter/material.dart';
import '../i18n.dart';
import '../logic.dart';
import '../models.dart';
import '../state.dart';
import '../widgets.dart';
import 'export_screen.dart';

class PassbookScreen extends StatelessWidget {
  const PassbookScreen({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: state,
        builder: (c, _) => state.hasData ? PassbookList(state.txns) : const EmptyState(),
      );
}

class PassbookList extends StatefulWidget {
  final List<Txn> txns;
  const PassbookList(this.txns, {super.key});
  @override
  State<PassbookList> createState() => _PassbookListState();
}

class _PassbookListState extends State<PassbookList> {
  String q = '';
  String? fy;
  String? mon;
  bool desc = true;

  @override
  Widget build(BuildContext c) {
    final fys = byFy(widget.txns).keys.toList()..sort();
    final mons = widget.txns.map((t) => t.month).toSet().toList()..sort();
    var l = widget.txns.where((t) {
      if (fy != null && fyOf(t.month) != fy) return false;
      if (mon != null && t.month != mon) return false;
      final s = q.toLowerCase();
      return s.isEmpty || t.month.contains(s) || monthLabel(t.month).toLowerCase().contains(s) || state.nameOf(t.memberId).toLowerCase().contains(s) || t.date.contains(s);
    }).toList();
    l = sorted(l, desc: desc);
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 4, 8),
        child: Row(children: [
          Expanded(child: TextField(onChanged: (v) => setState(() => q = v), decoration: InputDecoration(hintText: tr('Search month, company, date'), prefixIcon: const Icon(Icons.search), isDense: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(30))))),
          PopupMenuButton<String>(
            icon: const Icon(Icons.filter_list),
            tooltip: 'Financial year',
            onSelected: (v) => setState(() => fy = v == 'all' ? null : v),
            itemBuilder: (_) => [const PopupMenuItem(value: 'all', child: Text('All years')), for (final y in fys) PopupMenuItem(value: y, child: Text('FY $y'))],
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.calendar_month_outlined),
            tooltip: 'Month',
            onSelected: (v) => setState(() => mon = v == 'all' ? null : v),
            itemBuilder: (_) => [const PopupMenuItem(value: 'all', child: Text('All months')), for (final m in mons.reversed) PopupMenuItem(value: m, child: Text(monthLabel(m)))],
          ),
          IconButton(icon: Icon(desc ? Icons.arrow_downward : Icons.arrow_upward), tooltip: 'Sort by date', onPressed: () => setState(() => desc = !desc)),
          IconButton(icon: const Icon(Icons.download_outlined), tooltip: tr('Export'), onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const ExportScreen()))),
        ]),
      ),
      if (fy != null || mon != null) Padding(padding: const EdgeInsets.only(bottom: 4), child: Text('Filter: ${fy != null ? 'FY $fy ' : ''}${mon != null ? monthLabel(mon!) : ''}')),
      Expanded(
        child: l.isEmpty
            ? const Center(child: Text('No matching transactions'))
            : ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                itemCount: l.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (_, i) {
                  final t = l[i];
                  return Card(
                    child: ListTile(
                      onTap: () => showTxn(c, t),
                      title: Text('${monthLabel(t.month)} • ${state.nameOf(t.memberId)}', maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('Emp ${inr(t.emp)}  Er ${inr(t.er)}  EPS ${inr(t.eps)}${t.wd > 0 ? '  Wd ${inr(t.wd)}' : ''}'),
                      trailing: Text(inr(t.closing), style: const TextStyle(fontWeight: FontWeight.w700)),
                    ),
                  );
                },
              ),
      ),
    ]);
  }
}
