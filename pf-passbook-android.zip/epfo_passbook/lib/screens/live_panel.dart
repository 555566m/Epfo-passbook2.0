import 'package:flutter/material.dart';
import '../lock.dart';
import '../logic.dart';
import '../models.dart';
import '../theme.dart';
import 'online_passbook.dart';

/// Home panel built from the EPFO portal's own home page (live data).
class LivePanel extends StatelessWidget {
  final LiveSummary s;
  const LivePanel(this.s, {super.key});

  @override
  Widget build(BuildContext c) {
    final dark = Theme.of(c).brightness == Brightness.dark;
    final grey = Theme.of(c).colorScheme.onSurfaceVariant;
    Widget cell(String label, String value) => Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: grey)),
              const SizedBox(height: 6),
              FittedBox(fit: BoxFit.scaleDown, child: Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
            ]),
          ),
        );
    Widget info(String a, String b) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(width: 110, child: Text(a, style: TextStyle(color: grey))),
            Expanded(child: Text(b.isEmpty ? 'Data Not Available' : b, style: const TextStyle(fontWeight: FontWeight.w700))),
          ]),
        );
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(color: dark ? const Color(0xFF1A201D) : const Color(0xFFF3F3F3), borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Text('TOTAL EPF BALANCE', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: green.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(20)),
              child: const Text('LIVE • EPFO', style: TextStyle(color: green, fontWeight: FontWeight.w800, fontSize: 11)),
            ),
          ]),
          const SizedBox(height: 10),
          FittedBox(fit: BoxFit.scaleDown, child: Text(inr0(s.total), style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: green))),
          const Divider(height: 28),
          Row(children: [
            cell('Employee Share', s.emp == null ? 'Data Not Available' : inr0(s.emp!)),
            const SizedBox(width: 12),
            cell('Employer Share', s.er == null ? 'Data Not Available' : inr0(s.er!)),
          ]),
          Text('Shares as shown on the EPFO home page', style: TextStyle(fontSize: 11, color: grey)),
        ]),
      ),
      const SizedBox(height: 20),
      const Text('Current Establishment', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            info('Est. Name', s.estName),
            info('Est. Id', s.estId),
            info('Member Id', s.memberId),
            info('Joined', s.doj),
            info('Experience', s.exp),
          ]),
        ),
      ),
      const SizedBox(height: 20),
      const Text('Member Wise Balance', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      for (var i = 0; i < s.members.length; i++) Padding(padding: const EdgeInsets.only(bottom: 8), child: _MemberTile(i + 1, s.members[i])),
      Padding(
        padding: const EdgeInsets.fromLTRB(4, 8, 4, 0),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Total Balance', style: TextStyle(fontWeight: FontWeight.w700)),
          Text(inr0(s.total), style: const TextStyle(fontWeight: FontWeight.w900, color: green)),
        ]),
      ),
      const SizedBox(height: 4),
      Text('Synced ${s.at}', style: Theme.of(c).textTheme.bodySmall),
    ]);
  }
}

class _MemberTile extends StatefulWidget {
  final int n;
  final MapEntry<String, double> m;
  const _MemberTile(this.n, this.m);
  @override
  State<_MemberTile> createState() => _MemberTileState();
}

class _MemberTileState extends State<_MemberTile> {
  bool reveal = false;

  Future<void> _toggle() async {
    if (!reveal && !await requireAuth(context)) return;
    if (mounted) setState(() => reveal = !reveal);
  }

  @override
  Widget build(BuildContext c) => Card(
        child: ListTile(
          onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => OnlinePassbookScreen(widget.m.key))),
          leading: CircleAvatar(radius: 14, child: Text('${widget.n}', style: const TextStyle(fontSize: 12))),
          title: Text(reveal ? widget.m.key : maskId(widget.m.key), style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          subtitle: const Text('Tap to open passbook'),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            Text(inr0(widget.m.value), style: const TextStyle(fontWeight: FontWeight.w900, color: green)),
            IconButton(visualDensity: VisualDensity.compact, icon: Icon(reveal ? Icons.visibility_off : Icons.visibility, size: 18), onPressed: _toggle),
          ]),
        ),
      );
}
