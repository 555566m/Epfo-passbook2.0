import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../epfo_js.dart';
import '../lock.dart';
import '../logic.dart';
import '../models.dart';
import '../state.dart';

/// Opens the official EPFO passbook page inside the app (after PIN / fingerprint).
Future<void> openSync(BuildContext c) async {
  if (!await requireAuth(c)) return;
  if (!c.mounted) return;
  await Navigator.push(c, MaterialPageRoute(builder: (_) => const SyncScreen()));
}

Future<void> editEpfoLogin(BuildContext c) async {
  final u = TextEditingController(), p = TextEditingController();
  final ok = await showDialog<bool>(
    context: c,
    builder: (d) => AlertDialog(
      title: const Text('Save EPFO login'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Stored encrypted on this device only, used only to auto-fill the official EPFO page. OTP is never stored.', style: TextStyle(fontSize: 12)),
        TextField(controller: u, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'UAN')),
        TextField(controller: p, obscureText: true, decoration: const InputDecoration(labelText: 'EPFO password')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Save')),
      ],
    ),
  );
  if (ok == true && u.text.trim().isNotEmpty && p.text.isNotEmpty) await state.saveCreds(u.text.trim(), p.text);
}

class SyncScreen extends StatefulWidget {
  const SyncScreen({super.key});
  @override
  State<SyncScreen> createState() => _SyncScreenState();
}

class _SyncScreenState extends State<SyncScreen> {
  late final WebViewController ctl;
  Timer? timer;
  String status = 'Loading EPFO page...';
  bool filled = false, clicked = false, manual = false;
  String lastHome = '';
  int lastSig = 0;

  String _now() => DateTime.now().toIso8601String().substring(0, 16).replaceAll('T', ' ');

  @override
  void initState() {
    super.initState();
    ctl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('EpfoApp', onMessageReceived: _onMsg)
      ..setNavigationDelegate(NavigationDelegate(
        // only the official EPFO domain may be opened inside this screen
        onNavigationRequest: (r) => (Uri.tryParse(r.url)?.host ?? '').endsWith('epfindia.gov.in') ? NavigationDecision.navigate : NavigationDecision.prevent,
        onPageStarted: (_) => filled = false,
      ))
      ..loadRequest(Uri.parse(epfoLoginUrl));
    timer = Timer.periodic(const Duration(seconds: 2), (_) => ctl.runJavaScript(lightProbe).catchError((_) {}));
  }

  @override
  void dispose() {
    timer?.cancel();
    ctl.clearCache();
    ctl.clearLocalStorage();
    WebViewCookieManager().clearCookies();
    super.dispose();
  }

  Future<void> _autofill() async {
    filled = true;
    final c = await state.epfoLogin();
    if (!mounted) return;
    if (c == null) {
      setState(() => status = 'Enter UAN, password and captcha. (Save login in Settings to auto-fill next time.)');
      return;
    }
    await ctl.runJavaScript(fillJs(c['uan']!, c['pw']!));
    if (mounted) setState(() => status = 'UAN and password filled. Type only the captcha.');
  }

  Future<void> _onMsg(JavaScriptMessage m) async {
    Map<String, dynamic> d;
    try {
      d = jsonDecode(m.message) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    if (!mounted) return;
    if (d['type'] == 'light') {
      if (d['login'] == true) {
        if (!filled) await _autofill();
        return;
      }
      final h = d['home'];
      if (h is String) {
        final s = parseHomeText(h, _now());
        final sig = jsonEncode((s?.toJson() ?? {})..remove('at'));
        if (s != null && sig != lastHome) {
          lastHome = sig;
          await state.saveLive(s);
          if (mounted) setState(() => status = 'EPF summary saved: ${inr0(s.total)}, ${s.members.length} member IDs.');
        }
        if (s != null && !clicked) {
          clicked = true;
          await Future<void>.delayed(const Duration(seconds: 1));
          ctl.runJavaScript(clickPassbook).catchError((_) {});
          if (mounted) setState(() => status = 'Opening Passbook... choose a member ID if the page asks.');
        }
      }
      final n = (d['sig'] as num?)?.toInt() ?? 0;
      if (n > 0 && n != lastSig) {
        lastSig = n;
        ctl.runJavaScript(tablesProbe).catchError((_) {});
      }
    } else if (d['type'] == 'tables') {
      final tbs = [
        for (final t in (d['tables'] as List? ?? [])) [for (final r in (t as List)) [for (final c in (r as List)) c.toString()]]
      ];
      List<List<String>> best = [];
      var score = 0;
      for (final t in tbs) {
        final cols = t.fold<int>(0, (a, r) => r.length > a ? r.length : a);
        if (t.length * cols > score) {
          score = t.length * cols;
          best = t;
        }
      }
      final head = best.isEmpty ? '' : best.first.join(' ').toLowerCase();
      final looksLikePassbook = RegExp(r'month|date|contribution|particular|share|wage').hasMatch(head);
      final text = (d['text'] as String?) ?? '';
      if (!manual && !looksLikePassbook) return;
      if (best.isEmpty && text.length < 100) return;
      final mid = (d['mid'] as String?) ?? 'UNKNOWN';
      await state.savePassbook(mid, Captured(at: _now(), rows: best, text: best.isEmpty ? text : ''));
      manual = false;
      if (mounted) setState(() => status = best.isEmpty ? 'Page text saved for $mid (no table found).' : 'Passbook saved for $mid: ${best.length - 1} rows.');
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Online EPF Check', style: TextStyle(fontSize: 18))),
        body: Column(children: [
          Container(
            width: double.infinity,
            color: Theme.of(c).colorScheme.primaryContainer,
            padding: const EdgeInsets.all(10),
            child: Text(status, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ),
          Expanded(child: WebViewWidget(controller: ctl)),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                if (!state.hasCreds) Expanded(child: OutlinedButton(onPressed: () => editEpfoLogin(c), child: const Text('Save login'))),
                if (!state.hasCreds) const SizedBox(width: 8),
                Expanded(
                  child: FilledButton(
                    onPressed: () {
                      manual = true;
                      ctl.runJavaScript(tablesProbe);
                      setState(() => status = 'Capturing this page...');
                    },
                    child: const Text('Save this page'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(c), child: const Text('Done'))),
              ]),
            ),
          ),
        ]),
      );
}
