import 'package:flutter/material.dart';
import '../i18n.dart';
import '../logic.dart';
import '../state.dart';
import '../widgets.dart';

class ReportsScreen extends StatelessWidget {
  final int tab;
  const ReportsScreen({super.key, this.tab = 0});

  @override
  Widget build(BuildContext c) {
    final all = state.txns;
    final fy = byFy(all);
    final keys = fy.keys.toList()..sort((a, b) => b.compareTo(a));
    final months = <String, double>{};
    for (final x in all) {
      months[x.month] = (months[x.month] ?? 0) + x.deposits;
    }
    final mk = months.keys.toList()..sort();
    final lastM = mk.length > 12 ? mk.sublist(mk.length - 12) : mk;
    return DefaultTabController(
      length: 3,
      initialIndex: tab,
      child: Scaffold(
        appBar: AppBar(title: Text(tr('Reports')), bottom: TabBar(tabs: [Tab(text: tr('Monthly')), Tab(text: tr('Yearly')), Tab(text: tr('Interest'))])),
        body: all.isEmpty
            ? const EmptyState()
            : TabBarView(children: [
                ListView(padding: const EdgeInsets.all(16), children: [
                  Card(child: Padding(padding: const EdgeInsets.all(14), child: Bars([for (final k in lastM) MapEntry(k.substring(5), months[k]!)]))),
                  for (final t in sorted(all))
                    Padding(
                      padding: const EdgeInsets.only(top: 10),
                      child: Card(
                        child: ListTile(
                          title: Text('${monthLabel(t.month)} • ${state.nameOf(t.memberId)}'),
                          subtitle: Text('Emp ${inr(t.emp)}  Er ${inr(t.er)}  EPS ${inr(t.eps)}\nInterest: ${t.interest > 0 ? inr(t.interest) : 'none credited'}'),
                          trailing: Text(inr(t.deposits), style: const TextStyle(fontWeight: FontWeight.w700)),
                          isThreeLine: true,
                        ),
                      ),
                    ),
                ]),
                ListView(padding: const EdgeInsets.all(16), children: [
                  Card(child: Padding(padding: const EdgeInsets.all(14), child: Bars([for (final k in keys.reversed) MapEntry(k.substring(2), fy[k]!.fold(0.0, (s, t) => s + t.deposits))]))),
                  for (final k in keys) _year(k, fy[k]!),
                ]),
                ListView(padding: const EdgeInsets.all(16), children: [
                  Padding(padding: const EdgeInsets.only(bottom: 8), child: Text('ACTUAL = interest credited in your imported passbook. ESTIMATED (at ${state.rate}%) is indicative only: monthly opening balance x rate / 12. EPS earns no EPF interest.', style: const TextStyle(fontSize: 12))),
                  for (final k in keys) _interestCard(k, fy[k]!),
                  const SizedBox(height: 12),
                  const Text('Company-wise (actual credited)', style: TextStyle(fontWeight: FontWeight.w700)),
                  for (final co in state.companies)
                    Padding(padding: const EdgeInsets.only(top: 8), child: Card(child: ListTile(title: Text(co.name), trailing: Text(inr(Totals.of(forCompany(all, co.memberId)).interest))))),
                ]),
              ]),
      ),
    );
  }

  Widget _interestCard(String k, List txns) {
    final l = state.txns.where((t) => fyOf(t.month) == k).toList();
    final s = Totals.of(l);
    final est = state.companies.fold(0.0, (a, co) => a + estimateInterest(forCompany(l, co.memberId), state.rate));
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Card(
        child: ListTile(
          title: Text('FY $k'),
          isThreeLine: true,
          subtitle: Text('Actual: Employee ${inr(s.empInt)} / Employer ${inr(s.erInt)}\nESTIMATED: ${inr(est)}'),
          trailing: Text(inr(s.interest), style: const TextStyle(fontWeight: FontWeight.w700)),
        ),
      ),
    );
  }

  Widget _year(String k, List txns) {
    final l = state.txns.where((t) => fyOf(t.month) == k).toList();
    final t = Totals.of(l);
    final close = l.map((x) => x.memberId).toSet().fold(0.0, (s, id) => s + (latestClosing(forCompany(l, id)) ?? 0));
    Widget r(String a, String b) => Padding(padding: const EdgeInsets.symmetric(vertical: 2), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(a), Text(b, style: const TextStyle(fontWeight: FontWeight.w600))]));
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Align(alignment: Alignment.centerLeft, child: Text('FY $k', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
            r('Employee', inr(t.emp)), r('Employer', inr(t.er)), r('Pension (EPS)', inr(t.eps)),
            r('Interest (credited)', inr(t.interest)), r('Total deposits', inr(t.deposits)), r('Withdrawals', inr(t.wd)), r('Closing balance', inr(close)),
          ]),
        ),
      ),
    );
  }
}
