import 'package:flutter/material.dart';
import '../lock.dart';
import '../logic.dart';
import '../models.dart';
import '../state.dart';
import '../widgets.dart';
import 'passbook.dart';

class CompaniesScreen extends StatelessWidget {
  const CompaniesScreen({super.key});
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: state,
        builder: (c, _) {
          if (!state.hasData) return const EmptyState();
          return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 24), children: [
            for (final co in state.companies) Padding(padding: const EdgeInsets.only(bottom: 12), child: CompanyCard(co)),
          ]);
        },
      );
}

class CompanyCard extends StatefulWidget {
  final Company co;
  const CompanyCard(this.co, {super.key});
  @override
  State<CompanyCard> createState() => _CompanyCardState();
}

class _CompanyCardState extends State<CompanyCard> {
  bool reveal = false;

  Future<void> _toggle() async {
    if (!reveal && !await requireAuth(context)) return;
    if (mounted) setState(() => reveal = !reveal);
  }

  @override
  Widget build(BuildContext c) {
    final co = widget.co;
    final l = forCompany(state.txns, co.memberId);
    final t = Totals.of(l);
    final bal = latestClosing(l);
    Widget row(String a, String b) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(a, style: TextStyle(color: Theme.of(c).colorScheme.onSurfaceVariant)), Flexible(child: Text(b, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w600)))]));
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => CompanyDetail(co))),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Row(children: [
              Expanded(child: Text(co.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
              if (co.doe.isEmpty) const Chip(label: Text('Current'), visualDensity: VisualDensity.compact),
            ]),
            row('Establishment ID', na(co.estId)),
            Row(children: [
              Expanded(child: row('PF / Member ID', reveal ? co.memberId : maskId(co.memberId))),
              IconButton(visualDensity: VisualDensity.compact, icon: Icon(reveal ? Icons.visibility_off : Icons.visibility, size: 18), onPressed: _toggle),
            ]),
            row('Date of joining', na(co.doj)),
            row('Date of exit', co.doe.isEmpty ? 'Not exited / Not available' : co.doe),
            const Divider(),
            row('Employee share', inr(t.emp)),
            row('Employer share', inr(t.er)),
            row('Pension (EPS)', inr(t.eps)),
            row('Interest earned', inr(t.interest)),
            row('Total contribution', inr(t.deposits)),
            row('Available PF balance', bal == null ? 'Data Not Available' : inr(bal)),
          ]),
        ),
      ),
    );
  }
}

/// Only this company's records are shown. Other companies can be picked from the dropdown.
class CompanyDetail extends StatefulWidget {
  final Company co;
  const CompanyDetail(this.co, {super.key});
  @override
  State<CompanyDetail> createState() => _CompanyDetailState();
}

class _CompanyDetailState extends State<CompanyDetail> {
  late Company co = widget.co;

  @override
  Widget build(BuildContext c) {
    final l = forCompany(state.txns, co.memberId);
    final t = Totals.of(l);
    return Scaffold(
      appBar: AppBar(
        title: DropdownButton<String>(
          value: co.memberId,
          underline: const SizedBox.shrink(),
          items: [for (final x in state.companies) DropdownMenuItem(value: x.memberId, child: Text(x.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)))],
          onChanged: (v) => setState(() => co = state.companies.firstWhere((x) => x.memberId == v)),
        ),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
          child: Text('Employee ${inr(t.emp)}  •  Employer ${inr(t.er)}  •  EPS ${inr(t.eps)}  •  Interest ${inr(t.interest)}', style: Theme.of(c).textTheme.bodySmall),
        ),
        Expanded(child: PassbookList(l, key: ValueKey(co.memberId))),
      ]),
    );
  }
}
