import 'models.dart';

class Totals {
  final double emp, er, eps, empInt, erInt, wd;
  const Totals(this.emp, this.er, this.eps, this.empInt, this.erInt, this.wd);
  factory Totals.of(Iterable<Txn> l) {
    double a = 0, b = 0, c = 0, d = 0, e = 0, f = 0;
    for (final t in l) {
      a += t.emp; b += t.er; c += t.eps; d += t.empInt; e += t.erInt; f += t.wd;
    }
    return Totals(a, b, c, d, e, f);
  }
  double get interest => empInt + erInt;
  double get deposits => emp + er + eps;
}

class ParseResult {
  final Map<String, Company> companies = {};
  final List<Txn> txns = [];
  final List<String> errors = [];
}

const _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const fullMonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

String monthLabel(String m) {
  final p = m.split('-');
  if (p.length != 2) return m;
  final i = int.tryParse(p[1]) ?? 0;
  return (i >= 1 && i <= 12) ? '${_months[i - 1]} ${p[0]}' : m;
}

String monthFull(String m) => '${fullMonths[int.parse(m.substring(5, 7)) - 1]} ${m.substring(0, 4)}';

String monthInitial(String m) {
  final i = int.tryParse(m.substring(5, 7)) ?? 1;
  return _months[i - 1][0];
}

String fyOf(String month) {
  final y = int.parse(month.substring(0, 4));
  final m = int.parse(month.substring(5, 7));
  final s = m >= 4 ? y : y - 1;
  return '$s-${((s + 1) % 100).toString().padLeft(2, '0')}';
}

String na(String s) => s.trim().isEmpty ? 'Data Not Available' : s;

String maskId(String s) => s.length <= 4 ? s : '${'•' * (s.length - 4)}${s.substring(s.length - 4)}';

String inr(num v) {
  final neg = v < 0;
  final p = v.abs().toStringAsFixed(2).split('.');
  var i = p[0];
  if (i.length > 3) {
    final last = i.substring(i.length - 3);
    final rest = i.substring(0, i.length - 3);
    final b = StringBuffer();
    for (var k = 0; k < rest.length; k++) {
      if (k > 0 && (rest.length - k) % 2 == 0) b.write(',');
      b.write(rest[k]);
    }
    i = '$b,$last';
  }
  return '${neg ? '-' : ''}₹$i.${p[1]}';
}

String inr0(num v) => inr(v.round()).replaceAll(RegExp(r'\.00$'), '');

List<String> splitCsvLine(String l) {
  final out = <String>[];
  final b = StringBuffer();
  var q = false;
  for (var i = 0; i < l.length; i++) {
    final c = l[i];
    if (c == '"') {
      if (q && i + 1 < l.length && l[i + 1] == '"') {
        b.write('"');
        i++;
      } else {
        q = !q;
      }
    } else if (c == ',' && !q) {
      out.add(b.toString().trim());
      b.clear();
    } else {
      b.write(c);
    }
  }
  out.add(b.toString().trim());
  return out;
}

const requiredCols = [
  'company', 'member_id', 'month', 'date', 'opening', 'employee', 'employer',
  'pension', 'employee_interest', 'employer_interest', 'withdrawal', 'closing'
];

ParseResult parseCsv(String text) {
  final r = ParseResult();
  final lines = text.replaceFirst('\uFEFF', '').split('\n').map((e) => e.replaceAll('\r', '')).where((e) => e.trim().isNotEmpty).toList();
  if (lines.isEmpty) {
    r.errors.add('File is empty');
    return r;
  }
  final head = splitCsvLine(lines.first).map((e) => e.toLowerCase()).toList();
  final idx = <String, int>{for (var i = 0; i < head.length; i++) head[i]: i};
  final missing = requiredCols.where((c) => !idx.containsKey(c)).toList();
  if (missing.isNotEmpty) {
    r.errors.add('Missing columns: ${missing.join(', ')}');
    return r;
  }
  final seen = <String>{};
  for (var n = 1; n < lines.length; n++) {
    final c = splitCsvLine(lines[n]);
    String g(String k) => (idx[k]! < c.length) ? c[idx[k]!] : '';
    String go(String k) => idx.containsKey(k) ? g(k) : '';
    double num0(String k) => g(k).isEmpty ? 0 : (double.tryParse(g(k).replaceAll(',', '')) ?? double.nan);
    final month = g('month');
    if (!RegExp(r'^\d{4}-(0[1-9]|1[0-2])$').hasMatch(month) || g('member_id').isEmpty) {
      r.errors.add('Row ${n + 1}: invalid month or member_id');
      continue;
    }
    final vals = [num0('opening'), num0('employee'), num0('employer'), num0('pension'),
      num0('employee_interest'), num0('employer_interest'), num0('withdrawal'), num0('closing')];
    if (vals.any((v) => v.isNaN)) {
      r.errors.add('Row ${n + 1}: invalid number');
      continue;
    }
    final mid = g('member_id');
    final old = r.companies[mid];
    r.companies[mid] = Company(
        memberId: mid,
        name: g('company').isNotEmpty ? g('company') : (old?.name ?? mid),
        estId: go('establishment_id').isNotEmpty ? go('establishment_id') : (old?.estId ?? ''),
        doj: go('date_of_joining').isNotEmpty ? go('date_of_joining') : (old?.doj ?? ''),
        doe: go('date_of_exit').isNotEmpty ? go('date_of_exit') : (old?.doe ?? ''));
    final t = Txn(memberId: mid, month: month, date: g('date'), opening: vals[0], emp: vals[1],
        er: vals[2], eps: vals[3], empInt: vals[4], erInt: vals[5], wd: vals[6], closing: vals[7]);
    if (seen.add(t.key)) {
      r.txns.add(t);
    } else {
      r.errors.add('Row ${n + 1}: duplicate skipped');
    }
  }
  return r;
}

List<Txn> forCompany(List<Txn> all, String memberId) => all.where((t) => t.memberId == memberId).toList();

int _cmp(Txn a, Txn b) {
  final c = a.month.compareTo(b.month);
  return c != 0 ? c : a.date.compareTo(b.date);
}

double? latestClosing(Iterable<Txn> l) {
  if (l.isEmpty) return null;
  final s = l.toList()..sort(_cmp);
  return s.last.closing;
}

/// Sum of each company's latest closing balance (EPS is not part of EPF balance).
double totalBalance(List<Txn> all) {
  final ids = all.map((t) => t.memberId).toSet();
  return ids.fold(0.0, (s, id) => s + (latestClosing(forCompany(all, id)) ?? 0));
}

List<Txn> sorted(List<Txn> l, {bool desc = true}) {
  final s = List<Txn>.of(l)..sort(_cmp);
  return desc ? s.reversed.toList() : s;
}

Map<String, List<Txn>> byFy(List<Txn> l) {
  final m = <String, List<Txn>>{};
  for (final t in l) {
    m.putIfAbsent(fyOf(t.month), () => []).add(t);
  }
  return m;
}

/// ESTIMATE only: monthly opening balance x rate / 12, one entry per month.
/// Actual credited interest always comes from the passbook entries.
double estimateInterest(List<Txn> l, double ratePct) {
  final first = <String, Txn>{};
  for (final t in sorted(l, desc: false)) {
    first.putIfAbsent(t.month, () => t);
  }
  double s = 0;
  for (final t in first.values) {
    if (t.opening > 0) s += t.opening * ratePct / 1200;
  }
  return s;
}

String demoCsv() {
  final b = StringBuffer('company,establishment_id,member_id,date_of_joining,date_of_exit,month,date,opening,employee,employer,pension,employee_interest,employer_interest,withdrawal,closing\n');
  void gen(String name, String est, String mid, String doj, String doe, int y0, int m0, int n, double basic) {
    var bal = 0.0;
    var y = y0, m = m0;
    for (var i = 0; i < n; i++) {
      final emp = basic * 0.12;
      final eps = (basic > 15000 ? 15000 : basic) * 0.0833;
      final er = emp - eps;
      final close = bal + emp + er;
      final mm = m.toString().padLeft(2, '0');
      b.writeln('DEMO $name,$est,$mid,$doj,$doe,$y-$mm,$y-$mm-28,${bal.toStringAsFixed(2)},${emp.toStringAsFixed(2)},${er.toStringAsFixed(2)},${eps.toStringAsFixed(2)},0,0,0,${close.toStringAsFixed(2)}');
      bal = close;
      m++;
      if (m > 12) {
        m = 1;
        y++;
      }
    }
  }
  gen('Company A', 'DEMO0001', 'DEMOMEM001', '2023-04-01', '2024-09-30', 2023, 4, 18, 30000);
  gen('Company B', 'DEMO0002', 'DEMOMEM002', '2024-10-15', '', 2024, 10, 12, 40000);
  return b.toString();
}
