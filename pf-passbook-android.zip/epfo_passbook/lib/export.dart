import 'dart:convert';
import 'dart:io';
import 'package:excel/excel.dart' as xl;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'reports_data.dart';
import 'state.dart';

String csvOf(ReportData d) {
  String q(String s) => s.contains(',') || s.contains('"') ? '"${s.replaceAll('"', '""')}"' : s;
  return [d.headers, ...d.rows].map((r) => r.map(q).join(',')).join('\n');
}

List<int> xlsxOf(ReportData d) {
  final ex = xl.Excel.createExcel();
  ex.rename('Sheet1', 'Report');
  final s = ex['Report'];
  s.appendRow(<xl.CellValue?>[for (final h in d.headers) xl.TextCellValue(h)]);
  for (final r in d.rows) {
    s.appendRow(<xl.CellValue?>[
      for (var i = 0; i < r.length; i++)
        (d.numCols.contains(i) && double.tryParse(r[i]) != null) ? xl.DoubleCellValue(double.parse(r[i])) : xl.TextCellValue(r[i])
    ]);
  }
  return ex.save() ?? <int>[];
}

Future<List<int>> pdfOf(ReportData d) async {
  final doc = pw.Document();
  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4.landscape,
    build: (_) => [
      pw.Text('EPFO PASSBOOK - ${d.title}', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
      if (state.demo) pw.Text('DEMO DATA', style: const pw.TextStyle(color: PdfColors.red)),
      if (d.note.isNotEmpty) pw.Text(d.note, style: const pw.TextStyle(fontSize: 8)),
      pw.SizedBox(height: 10),
      pw.TableHelper.fromTextArray(
        headers: d.headers,
        data: d.rows,
        headerStyle: pw.TextStyle(fontSize: 7, fontWeight: pw.FontWeight.bold, color: PdfColors.white),
        headerDecoration: const pw.BoxDecoration(color: PdfColors.green800),
        cellStyle: const pw.TextStyle(fontSize: 7),
        cellAlignment: pw.Alignment.centerRight,
      ),
    ],
  ));
  return doc.save();
}

Future<void> shareBytes(String name, List<int> bytes) async {
  final f = File('${(await getTemporaryDirectory()).path}/$name');
  await f.writeAsBytes(bytes);
  await Share.shareXFiles([XFile(f.path)]);
}

/// fmt: 'pdf' | 'xlsx' | 'csv'
Future<void> exportReport(ReportData d, String fmt) async {
  final base = d.title.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_');
  switch (fmt) {
    case 'pdf':
      return shareBytes('$base.pdf', await pdfOf(d));
    case 'xlsx':
      return shareBytes('$base.xlsx', xlsxOf(d));
    default:
      return shareBytes('$base.csv', utf8.encode(csvOf(d)));
  }
}
